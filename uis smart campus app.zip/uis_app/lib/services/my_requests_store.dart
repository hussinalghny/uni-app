import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// kind: 'service' or 'voice'
class SavedRequest {
  final String kind;
  final String number;
  final DateTime savedAt;

  SavedRequest({required this.kind, required this.number, required this.savedAt});

  Map<String, dynamic> toJson() =>
      {'kind': kind, 'number': number, 'saved_at': savedAt.toIso8601String()};

  factory SavedRequest.fromJson(Map<String, dynamic> j) => SavedRequest(
        kind: j['kind'],
        number: j['number'],
        savedAt: DateTime.tryParse(j['saved_at'] ?? '') ?? DateTime.now(),
      );
}

/// Saves the request/ticket numbers a person has submitted from THIS
/// device, so they can come back later and check status without any
/// account or login — the app remembers on their behalf.
class MyRequestsStore {
  static const _key = 'uis_my_requests';

  static Future<List<SavedRequest>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list.map((e) => SavedRequest.fromJson(e)).toList().reversed.toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> add(String kind, String number) async {
    if (number.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    final current = await load();
    // newest-first list was reversed on load; re-reverse before saving
    final chronological = current.reversed.toList();
    chronological.add(SavedRequest(kind: kind, number: number, savedAt: DateTime.now()));
    final raw = jsonEncode(chronological.map((e) => e.toJson()).toList());
    await prefs.setString(_key, raw);
  }

  static Future<void> remove(String number) async {
    final prefs = await SharedPreferences.getInstance();
    final current = await load();
    final chronological =
        current.reversed.where((e) => e.number != number).toList();
    final raw = jsonEncode(chronological.map((e) => e.toJson()).toList());
    await prefs.setString(_key, raw);
  }
}

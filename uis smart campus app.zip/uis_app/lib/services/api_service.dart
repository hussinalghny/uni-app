import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

import '../core/api_config.dart';
import '../core/auth_token_store.dart';
import '../models/news_item.dart';
import '../models/event_item.dart';
import '../models/college_item.dart';
import '../models/banner_item.dart';
import '../models/service_item.dart';
import '../models/directory_contact_item.dart';
import '../models/contact_channel_item.dart';
import '../models/media_item_model.dart';
import '../models/app_notification_item.dart';
import '../models/map_location_item.dart';
import '../models/app_config_data.dart';
import '../models/student_user.dart';

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

class SearchResults {
  final List<CollegeItem> colleges;
  final List<NewsItem> news;
  final List<EventItem> events;
  final List<ServiceItem> services;
  SearchResults({
    this.colleges = const [],
    this.news = const [],
    this.events = const [],
    this.services = const [],
  });
  bool get isEmpty =>
      colleges.isEmpty && news.isEmpty && events.isEmpty && services.isEmpty;
}

class ApiService {
  final http.Client _client = http.Client();

  Map<String, String> get _headers => {
        'Accept': 'application/json',
        if (ApiConfig.apiKey.isNotEmpty) 'X-API-Key': ApiConfig.apiKey,
        if (AuthTokenStore.token != null) 'Authorization': 'Bearer ${AuthTokenStore.token}',
      };

  Uri _uri(String path, [Map<String, String>? query]) =>
      Uri.parse('${ApiConfig.apiBaseUrl}/$path').replace(queryParameters: query);

  Future<dynamic> _get(String path, [Map<String, String>? query]) async {
    try {
      final res = await _client
          .get(_uri(path, query), headers: _headers)
          .timeout(const Duration(seconds: 20));
      if (res.statusCode >= 200 && res.statusCode < 300) {
        return jsonDecode(utf8.decode(res.bodyBytes));
      }
      throw ApiException(_extractMessage(res.body) ?? 'HTTP ${res.statusCode}');
    } on SocketException {
      throw ApiException('network');
    } on TimeoutException {
      throw ApiException('network');
    } on ApiException {
      rethrow;
    } catch (e) {
      // Anything else (bad TLS handshake, malformed JSON, DNS failure...)
      // still becomes a normal ApiException instead of an unhandled crash.
      throw ApiException(e.toString());
    }
  }

  Future<dynamic> _postJson(String path, Map<String, dynamic> body) async {
    try {
      final res = await _client
          .post(_uri(path), headers: {..._headers, 'Content-Type': 'application/json'},
              body: jsonEncode(body))
          .timeout(const Duration(seconds: 20));
      if (res.statusCode >= 200 && res.statusCode < 300) {
        return jsonDecode(utf8.decode(res.bodyBytes));
      }
      throw ApiException(_extractMessage(res.body) ?? 'HTTP ${res.statusCode}');
    } on SocketException {
      throw ApiException('network');
    } on TimeoutException {
      throw ApiException('network');
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(e.toString());
    }
  }

  /// Multipart POST — used for endpoints that accept an optional file
  /// attachment (voice requests, service requests).
  Future<dynamic> _postMultipart(
    String path,
    Map<String, String> fields, {
    File? file,
    String fileField = 'attachment',
  }) async {
    try {
      final req = http.MultipartRequest('POST', _uri(path));
      req.headers.addAll(_headers);
      req.fields.addAll(fields);
      if (file != null) {
        req.files.add(await http.MultipartFile.fromPath(fileField, file.path));
      }
      final streamed = await req.send().timeout(const Duration(seconds: 30));
      final res = await http.Response.fromStream(streamed);
      if (res.statusCode >= 200 && res.statusCode < 300) {
        return jsonDecode(utf8.decode(res.bodyBytes));
      }
      throw ApiException(_extractMessage(res.body) ?? 'HTTP ${res.statusCode}');
    } on SocketException {
      throw ApiException('network');
    } on TimeoutException {
      throw ApiException('network');
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException(e.toString());
    }
  }

  String? _extractMessage(String body) {
    try {
      final j = jsonDecode(body);
      if (j is Map) {
        // Laravel validation errors (422) put the specific, friendlier
        // message inside "errors", while "message" is a generic string
        // like "The given data was invalid." — prefer the specific one.
        final errors = j['errors'];
        if (errors is Map && errors.isNotEmpty) {
          final first = errors.values.first;
          if (first is List && first.isNotEmpty) return first.first.toString();
        }
        if (j['message'] != null) return j['message'].toString();
      }
    } catch (_) {}
    return null;
  }

  // ---------------- Config / Search ----------------

  Future<AppConfigData> getConfig() async {
    final j = await _get('config');
    return AppConfigData.fromJson(j);
  }

  Future<List<BannerItem>> getBanners() async {
    final j = await _get('banners');
    return (j as List).map((e) => BannerItem.fromJson(e)).toList();
  }

  Future<SearchResults> search(String q) async {
    if (q.trim().isEmpty) return SearchResults();
    final j = await _get('search', {'q': q});
    return SearchResults(
      colleges: (j['colleges'] as List? ?? []).map((e) => CollegeItem.fromJson(e)).toList(),
      news: (j['news'] as List? ?? []).map((e) => NewsItem.fromJson(e)).toList(),
      events: (j['events'] as List? ?? []).map((e) => EventItem.fromJson(e)).toList(),
      services: (j['services'] as List? ?? []).map((e) => ServiceItem.fromJson(e)).toList(),
    );
  }

  // ---------------- News ----------------

  Future<List<NewsItem>> getNews({String? category, String? q, int perPage = 20}) async {
    final query = <String, String>{'per_page': '$perPage'};
    if (category != null && category != 'all') query['category'] = category;
    if (q != null && q.isNotEmpty) query['q'] = q;
    final j = await _get('news', query);
    final data = (j['data'] as List? ?? []);
    return data.map((e) => NewsItem.fromJson(e)).toList();
  }

  Future<NewsItem> getNewsDetail(int id) async {
    final j = await _get('news/$id');
    return NewsItem.fromJson(j);
  }

  // ---------------- Events ----------------

  Future<List<EventItem>> getEvents({String? category, bool upcoming = true}) async {
    final query = <String, String>{'upcoming': upcoming ? '1' : '0', 'per_page': '50'};
    if (category != null && category != 'all') query['category'] = category;
    final j = await _get('events', query);
    final data = (j['data'] as List? ?? []);
    return data.map((e) => EventItem.fromJson(e)).toList();
  }

  Future<EventItem> getEventDetail(int id) async {
    final j = await _get('events/$id');
    return EventItem.fromJson(j);
  }

  Future<void> registerForEvent(int eventId,
      {required String name, String? email, String? phone}) async {
    await _postJson('events/$eventId/register', {
      'name': name,
      if (email != null && email.isNotEmpty) 'email': email,
      if (phone != null && phone.isNotEmpty) 'phone': phone,
    });
  }

  // ---------------- Colleges ----------------

  Future<List<CollegeItem>> getColleges() async {
    final j = await _get('colleges');
    return (j as List).map((e) => CollegeItem.fromJson(e)).toList();
  }

  Future<CollegeItem> getCollegeDetail(int id) async {
    final j = await _get('colleges/$id');
    return CollegeItem.fromJson(j);
  }

  // ---------------- Services ----------------

  Future<List<ServiceItem>> getServices() async {
    final j = await _get('services');
    return (j as List).map((e) => ServiceItem.fromJson(e)).toList();
  }

  Future<ServiceItem> getServiceDetail(int id) async {
    final j = await _get('services/$id');
    return ServiceItem.fromJson(j);
  }

  /// Returns the generated request_number on success.
  Future<String> submitServiceRequest(
    int serviceId, {
    required String name,
    String? email,
    String? phone,
    File? attachment,
  }) async {
    final j = await _postMultipart(
      'services/$serviceId/request',
      {
        'name': name,
        if (email != null && email.isNotEmpty) 'email': email,
        if (phone != null && phone.isNotEmpty) 'phone': phone,
      },
      file: attachment,
    );
    return j['request_number']?.toString() ?? '';
  }

  /// Public status lookup — no account needed, the request number itself
  /// (e.g. UIS-2026-00482) is the access key.
  Future<Map<String, dynamic>> trackServiceRequest(String requestNumber) async {
    return await _get('services/track/$requestNumber') as Map<String, dynamic>;
  }

  // ---------------- Directory / Contact ----------------

  Future<List<DirectoryContactItem>> getDirectory({String? q}) async {
    final query = <String, String>{};
    if (q != null && q.isNotEmpty) query['q'] = q;
    final j = await _get('directory', query);
    return (j as List).map((e) => DirectoryContactItem.fromJson(e)).toList();
  }

  Future<List<ContactChannelItem>> getContacts() async {
    final j = await _get('contacts');
    return (j as List).map((e) => ContactChannelItem.fromJson(e)).toList();
  }

  // ---------------- Media ----------------

  Future<List<MediaItemModel>> getMedia({String? type}) async {
    final query = <String, String>{};
    if (type != null) query['type'] = type;
    final j = await _get('media', query);
    return (j as List).map((e) => MediaItemModel.fromJson(e)).toList();
  }

  // ---------------- Notifications ----------------

  Future<List<AppNotificationItem>> getNotifications() async {
    final j = await _get('notifications');
    return (j as List).map((e) => AppNotificationItem.fromJson(e)).toList();
  }

  // ---------------- Map ----------------

  Future<CampusMapData> getMap() async {
    final j = await _get('map');
    return CampusMapData.fromJson(j);
  }

  // ---------------- Voice of the University ----------------

  /// Returns the generated ticket_number on success.
  Future<String> submitVoiceRequest({
    required String type, // complaint | suggestion | inquiry | report
    required String name,
    String? email,
    String? phone,
    required String message,
    File? attachment,
  }) async {
    final j = await _postMultipart(
      'voice',
      {
        'type': type,
        'name': name,
        if (email != null && email.isNotEmpty) 'email': email,
        if (phone != null && phone.isNotEmpty) 'phone': phone,
        'message': message,
      },
      file: attachment,
    );
    return j['ticket_number']?.toString() ?? '';
  }

  /// Public status lookup — no account needed, same idea as
  /// [trackServiceRequest].
  Future<Map<String, dynamic>> trackVoiceTicket(String ticketNumber) async {
    return await _get('voice/track/$ticketNumber') as Map<String, dynamic>;
  }

  // ---------------- UIS AI ----------------

  Future<String> aiChat({
    required String message,
    required List<Map<String, String>> history,
    required String lang,
    String? sessionId,
  }) async {
    final j = await _postJson('ai/chat', {
      'message': message,
      'history': history,
      'lang': lang,
      if (sessionId != null) 'session_id': sessionId,
    });
    return j['reply']?.toString() ?? '';
  }

  // ---------------- Student accounts ----------------

  Future<(String token, StudentUser student)> register({
    required String name,
    required String email,
    required String password,
    String? phone,
    String? studentNumber,
  }) async {
    final j = await _postJson('auth/register', {
      'name': name,
      'email': email,
      'password': password,
      if (phone != null && phone.isNotEmpty) 'phone': phone,
      if (studentNumber != null && studentNumber.isNotEmpty) 'student_number': studentNumber,
    });
    return (j['token'] as String, StudentUser.fromJson(j['student']));
  }

  Future<(String token, StudentUser student)> login({
    required String email,
    required String password,
  }) async {
    final j = await _postJson('auth/login', {'email': email, 'password': password});
    return (j['token'] as String, StudentUser.fromJson(j['student']));
  }

  Future<void> logout() async {
    try {
      await _postJson('auth/logout', {});
    } catch (_) {
      // Even if the server call fails (e.g. token already expired), the
      // caller still clears the local token — logging out is a client-side
      // guarantee, not something that should get stuck on a network error.
    }
  }

  Future<StudentUser> me() async {
    final j = await _get('auth/me');
    return StudentUser.fromJson(j);
  }

  // ---------------- Push notifications ----------------

  Future<void> registerDeviceToken(String fcmToken, {String? platform}) async {
    await _postJson('device-tokens', {
      'fcm_token': fcmToken,
      if (platform != null) 'platform': platform,
    });
  }
}

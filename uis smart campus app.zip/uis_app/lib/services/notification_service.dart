import 'dart:io';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'api_service.dart';

/// Handles a message that arrives while the app is fully terminated or in
/// the background. Must be a top-level (or static) function — Firebase
/// spins this up in its own isolate, so it can't touch app state directly.
@pragma('vm:entry-point')
Future<void> firebaseBackgroundHandler(RemoteMessage message) async {
  // Nothing to do here: when the app is backgrounded/terminated, FCM
  // already shows the system tray notification automatically because our
  // payload includes a "notification" block (not just silent "data").
  // This handler exists so data-only follow-up logic can be added later
  // without needing to touch the app's UI code.
}

/// One place for everything push-notification related: permissions, the
/// FCM token lifecycle, showing a heads-up alert while the app is open
/// (FCM does NOT do this automatically in the foreground), and routing a
/// notification tap to the right screen.
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _local = FlutterLocalNotificationsPlugin();
  final ApiService _api = ApiService();

  /// Called by the app (e.g. from AccountScreen after login, or on a
  /// tapped notification) to open the right screen. Set once from main.dart.
  void Function(Map<String, dynamic> data)? onNotificationTap;

  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;
    _initialized = true;

    try {
      await Firebase.initializeApp();
    } catch (e) {
      // Firebase not configured yet (missing google-services.json etc.) —
      // fail quietly so the rest of the app keeps working without push.
      debugPrint('Firebase init skipped: $e');
      return;
    }

    FirebaseMessaging.onBackgroundMessage(firebaseBackgroundHandler);

    await _initLocalNotifications();
    await _requestPermission();
    await _registerToken();

    FirebaseMessaging.instance.onTokenRefresh.listen((newToken) {
      _sendTokenToServer(newToken);
    });

    // Broadcast/general topic — news + admin "send general notification".
    await FirebaseMessaging.instance.subscribeToTopic('all_devices');

    // Foreground: FCM delivers the message but does NOT show a system
    // banner by default, so we show one ourselves via local notifications.
    FirebaseMessaging.onMessage.listen(_showLocalNotification);

    // App was in background and the person tapped the system notification.
    FirebaseMessaging.onMessageOpenedApp.listen((message) {
      onNotificationTap?.call(message.data);
    });

    // App was fully terminated and got opened BY tapping a notification.
    final initialMessage = await FirebaseMessaging.instance.getInitialMessage();
    if (initialMessage != null) {
      onNotificationTap?.call(initialMessage.data);
    }
  }

  Future<void> _initLocalNotifications() async {
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings();
    await _local.initialize(
      const InitializationSettings(android: androidInit, iOS: iosInit),
      onDidReceiveNotificationResponse: (response) {
        // Tapped while the app was already in the foreground.
        if (response.payload != null && response.payload!.isNotEmpty) {
          onNotificationTap?.call({'type': response.payload});
        }
      },
    );

    const channel = AndroidNotificationChannel(
      'uis_general',
      'إشعارات عامة',
      description: 'أخبار وفعاليات وتحديثات من UIS Smart Campus',
      importance: Importance.high,
    );
    await _local
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
  }

  Future<void> _requestPermission() async {
    await FirebaseMessaging.instance.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );
  }

  Future<void> _registerToken() async {
    try {
      final token = await FirebaseMessaging.instance.getToken();
      if (token != null) await _sendTokenToServer(token);
    } catch (e) {
      debugPrint('Could not fetch FCM token: $e');
    }
  }

  /// Call this again right after a successful login so the token gets
  /// (re-)linked to the now-known student account.
  Future<void> refreshTokenLink() => _registerToken();

  Future<void> _sendTokenToServer(String token) async {
    try {
      await _api.registerDeviceToken(
        token,
        platform: Platform.isIOS ? 'ios' : 'android',
      );
    } catch (e) {
      debugPrint('Failed to register device token: $e');
    }
  }

  void _showLocalNotification(RemoteMessage message) {
    final notification = message.notification;
    if (notification == null) return;

    _local.show(
      notification.hashCode,
      notification.title,
      notification.body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'uis_general',
          'إشعارات عامة',
          importance: Importance.high,
          priority: Priority.high,
        ),
        iOS: DarwinNotificationDetails(),
      ),
      payload: message.data['type'] as String?,
    );
  }
}

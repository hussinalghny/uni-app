import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../services/api_service.dart';
import '../widgets/empty_state.dart';

/// Dedicated WebView for the student registration flow. The URL itself is
/// NOT hard-coded — it's set by the admin from the control panel (Settings
/// > تسجيل الطلبة), so it can point at whatever real registration system
/// the university uses (internal page or external portal) without needing
/// an app update to change it.
class RegistrationWebViewScreen extends StatefulWidget {
  const RegistrationWebViewScreen({super.key});

  @override
  State<RegistrationWebViewScreen> createState() => _RegistrationWebViewScreenState();
}

class _RegistrationWebViewScreenState extends State<RegistrationWebViewScreen> {
  WebViewController? _controller;
  bool _loading = true;
  String? _url;
  String? _error;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      final config = await ApiService().getConfig();
      if (config.registrationUrl == null || config.registrationUrl!.isEmpty) {
        setState(() {
          _loading = false;
          _error = 'unavailable';
        });
        return;
      }
      _url = config.registrationUrl;
      final controller = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setNavigationDelegate(NavigationDelegate(
          onPageFinished: (_) {
            if (mounted) setState(() => _loading = false);
          },
        ))
        ..loadRequest(Uri.parse(_url!));
      setState(() => _controller = controller);
    } catch (_) {
      setState(() {
        _loading = false;
        _error = 'unavailable';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(app.t('registration'))),
      body: _error != null
          ? EmptyState(icon: Icons.link_off, title: app.t('registrationUnavailable'))
          : Stack(
              children: [
                if (_controller != null) WebViewWidget(controller: _controller!),
                if (_loading)
                  const Center(child: CircularProgressIndicator(color: AppColors.maroon)),
              ],
            ),
    );
  }
}

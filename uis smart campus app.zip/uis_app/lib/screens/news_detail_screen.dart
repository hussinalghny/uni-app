import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../core/date_utils.dart';
import '../models/news_item.dart';
import '../services/api_service.dart';
import '../widgets/async_view.dart';
import '../widgets/net_image.dart';

class NewsDetailScreen extends StatelessWidget {
  final int id;
  const NewsDetailScreen({super.key, required this.id});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final api = ApiService();
    return Scaffold(
      body: AsyncView<NewsItem>(
        loader: () => api.getNewsDetail(id),
        builder: (context, item) {
          return CustomScrollView(
            slivers: [
              SliverAppBar(
                expandedHeight: 220,
                pinned: true,
                iconTheme: const IconThemeData(color: Colors.white),
                flexibleSpace: FlexibleSpaceBar(
                  background: Stack(
                    fit: StackFit.expand,
                    children: [
                      NetImage(url: item.imageUrl, fallbackIcon: 'news'),
                      Container(color: Colors.black.withOpacity(0.35)),
                    ],
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF1E1DE),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(app.t(item.category),
                            style: const TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w800,
                                color: AppColors.maroon)),
                      ),
                      const SizedBox(height: 12),
                      Text(item.title(app.isArabic),
                          style: const TextStyle(
                              fontSize: 19, fontWeight: FontWeight.w800, height: 1.4)),
                      const SizedBox(height: 10),
                      if (item.publishedAt != null)
                        Row(
                          children: [
                            const Icon(Icons.calendar_today_outlined,
                                size: 13, color: AppColors.muted),
                            const SizedBox(width: 6),
                            Text(formatDate(item.publishedAt!, app.isArabic),
                                style:
                                    const TextStyle(fontSize: 11.5, color: AppColors.muted)),
                          ],
                        ),
                      const SizedBox(height: 18),
                      Text(item.body(app.isArabic),
                          style: const TextStyle(fontSize: 13.5, height: 2)),
                      const SizedBox(height: 20),
                      OutlinedButton.icon(
                        onPressed: () => _share(context, item, app.isArabic),
                        icon: const Icon(Icons.share_outlined, size: 16),
                        label: Text(app.t('share')),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  void _share(BuildContext context, NewsItem item, bool ar) {
    // No share_plus dependency to keep the package footprint minimal and
    // avoid an untested native-integration dependency — copies to the
    // clipboard instead. Swap this for share_plus later if you want the
    // native OS share sheet.
    Clipboard.setData(ClipboardData(text: item.title(ar)));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(Provider.of<AppState>(context, listen: false).t('copied'))),
    );
  }
}

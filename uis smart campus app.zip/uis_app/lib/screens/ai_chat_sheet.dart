import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../services/api_service.dart';

void showAiChatSheet(BuildContext context) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Theme.of(context).scaffoldBackgroundColor,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (_) => const _AiChatSheet(),
  );
}

class _ChatMsg {
  final bool isUser;
  final String text;
  _ChatMsg(this.isUser, this.text);
}

class _AiChatSheet extends StatefulWidget {
  const _AiChatSheet();

  @override
  State<_AiChatSheet> createState() => _AiChatSheetState();
}

class _AiChatSheetState extends State<_AiChatSheet> {
  final _api = ApiService();
  final _controller = TextEditingController();
  final _scrollController = ScrollController();
  final List<_ChatMsg> _messages = [];
  bool _sending = false;
  String? _sessionId;

  @override
  void initState() {
    super.initState();
    final app = context.read<AppState>();
    _messages.add(_ChatMsg(false, app.t('aiWelcome')));
  }

  Future<void> _send(String text) async {
    if (text.trim().isEmpty || _sending) return;
    final app = context.read<AppState>();
    setState(() {
      _messages.add(_ChatMsg(true, text));
      _sending = true;
      _controller.clear();
    });
    _scrollToBottom();

    try {
      final history = _messages
          .map((m) => {'role': m.isUser ? 'user' : 'assistant', 'content': m.text})
          .toList();
      final reply = await _api.aiChat(
        message: text,
        history: history.length > 1 ? history.sublist(0, history.length - 1) : [],
        lang: app.lang,
        sessionId: _sessionId,
      );
      if (!mounted) return;
      setState(() {
        _messages.add(_ChatMsg(false, reply.isNotEmpty ? reply : app.t('networkError')));
        _sending = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _messages.add(_ChatMsg(false, app.t('networkError')));
        _sending = false;
      });
    }
    _scrollToBottom();
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.78,
        child: SafeArea(
          child: Column(
            children: [
              Container(
                width: 38,
                height: 4,
                margin: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: AppColors.line,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 18),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 18,
                      backgroundColor: AppColors.gold,
                      child: const Icon(Icons.auto_awesome, color: Colors.white, size: 16),
                    ),
                    const SizedBox(width: 10),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(app.t('aiName'),
                            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                        Text(app.t('aiSub'),
                            style: const TextStyle(fontSize: 10.5, color: AppColors.muted)),
                      ],
                    ),
                  ],
                ),
              ),
              const Divider(height: 20),
              Expanded(
                child: ListView.builder(
                  controller: _scrollController,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: _messages.length + (_sending ? 1 : 0),
                  itemBuilder: (context, i) {
                    if (i == _messages.length) {
                      return _bubble(context, false, '…', isDark, typing: true);
                    }
                    final m = _messages[i];
                    return _bubble(context, m.isUser, m.text, isDark);
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(14),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _controller,
                        textInputAction: TextInputAction.send,
                        onSubmitted: _send,
                        decoration: InputDecoration(
                          hintText: app.t('aiPlaceholder'),
                          filled: true,
                          fillColor:
                              isDark ? AppColors.darkSurface : AppColors.cream2,
                          contentPadding:
                              const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(24),
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    CircleAvatar(
                      radius: 22,
                      backgroundColor: AppColors.maroon,
                      child: IconButton(
                        icon: const Icon(Icons.send, color: Colors.white, size: 18),
                        onPressed: () => _send(_controller.text),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _bubble(BuildContext context, bool isUser, String text, bool isDark,
      {bool typing = false}) {
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.72),
        decoration: BoxDecoration(
          color: isUser
              ? AppColors.maroon
              : (isDark ? AppColors.darkSurface : AppColors.cream2),
          borderRadius: BorderRadius.circular(16),
        ),
        child: typing
            ? const SizedBox(
                width: 20,
                height: 12,
                child: Center(
                  child: SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                ),
              )
            : Text(
                text,
                style: TextStyle(
                  color: isUser ? Colors.white : null,
                  fontSize: 12.5,
                  height: 1.5,
                ),
              ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../core/icon_map.dart';
import '../models/app_config_data.dart';
import '../models/news_item.dart';
import '../models/event_item.dart';
import '../models/banner_item.dart';
import '../services/api_service.dart';
import '../widgets/async_view.dart';
import '../widgets/section_header.dart';
import '../widgets/news_card.dart';
import '../widgets/event_card.dart';
import '../widgets/net_image.dart';
import '../widgets/promo_carousel.dart';
import 'news_screen.dart';
import 'news_detail_screen.dart';
import 'events_screen.dart';
import 'event_detail_screen.dart';
import 'services_screen.dart';
import 'colleges_screen.dart';
import 'directory_screen.dart';
import 'map_screen.dart';
import 'notifications_screen.dart';
import 'settings_screen.dart';
import 'search_screen.dart';
import 'account_screen.dart';
import 'contact_screen.dart';
import 'voice_screen.dart';
import 'media_screen.dart';
import 'registration_webview_screen.dart';

class _HomeData {
  final AppConfigData config;
  final List<NewsItem> news;
  final List<EventItem> events;
  final List<BannerItem> banners;
  _HomeData(this.config, this.news, this.events, this.banners);
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Future<_HomeData> _load(ApiService api) async {
    final results = await Future.wait([
      api.getConfig(),
      api.getNews(perPage: 8),
      api.getEvents(),
      api.getBanners(),
    ]);
    return _HomeData(
      results[0] as AppConfigData,
      results[1] as List<NewsItem>,
      (results[2] as List<EventItem>).take(3).toList(),
      results[3] as List<BannerItem>,
    );
  }

  void _openBannerTarget(BuildContext context, String target) {
    final routes = <String, WidgetBuilder>{
      'news': (_) => const NewsScreen(),
      'events': (_) => const EventsScreen(),
      'services': (_) => const ServicesScreen(),
      'colleges': (_) => const CollegesScreen(),
      'directory': (_) => const DirectoryScreen(),
      'map': (_) => const MapScreen(),
      'media': (_) => const MediaScreen(),
      'contact': (_) => const ContactScreen(),
      'voice': (_) => const VoiceScreen(),
      'registration': (_) => const RegistrationWebViewScreen(),
    };
    final builder = routes[target];
    if (builder != null) {
      Navigator.of(context).push(MaterialPageRoute(builder: builder));
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final api = ApiService();

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Row(
          children: [
            const CircleAvatar(
              radius: 18,
              backgroundColor: Color(0xFFF4D9AE),
              child: Text('UIS',
                  style: TextStyle(
                      fontSize: 9, fontWeight: FontWeight.w900, color: AppColors.maroon)),
            ),
            const SizedBox(width: 10),
            Text(app.t('welcome'), style: const TextStyle(fontSize: 14)),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () => Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const SearchScreen())),
          ),
          IconButton(
            icon: const Icon(Icons.notifications_none_outlined),
            onPressed: () => Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const NotificationsScreen())),
          ),
          IconButton(
            icon: const Icon(Icons.person_outline),
            onPressed: () => Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const AccountScreen())),
          ),
        ],
      ),
      body: AsyncView<_HomeData>(
        loader: () => _load(api),
        builder: (context, data) {
          return RefreshIndicator(
            onRefresh: () async {},
            child: ListView(
              padding: const EdgeInsets.only(bottom: 90),
              children: [
                if (data.banners.isNotEmpty)
                  PromoCarousel(
                    banners: data.banners,
                    onTap: (target) => _openBannerTarget(context, target),
                  )
                else
                  _Hero(config: data.config, app: app),
                _QuickActionsGrid(app: app),
                SectionHeader(
                  title: app.t('latestNews'),
                  eyebrow: 'Newsroom',
                  onViewAll: () => Navigator.of(context)
                      .push(MaterialPageRoute(builder: (_) => const NewsScreen())),
                  viewAllLabel: app.t('viewAll'),
                ),
                SizedBox(
                  height: 210,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 18),
                    itemCount: data.news.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 12),
                    itemBuilder: (context, i) {
                      final n = data.news[i];
                      return NewsCard(
                        item: n,
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => NewsDetailScreen(id: n.id)),
                        ),
                      );
                    },
                  ),
                ),
                SectionHeader(
                  title: app.t('upcomingEvents'),
                  eyebrow: 'Campus Life',
                  onViewAll: () => Navigator.of(context)
                      .push(MaterialPageRoute(builder: (_) => const EventsScreen())),
                  viewAllLabel: app.t('viewAll'),
                ),
                ...data.events.map((e) => EventCard(
                      item: e,
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => EventDetailScreen(id: e.id)),
                      ),
                    )),
                const SizedBox(height: 8),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _Hero extends StatelessWidget {
  final AppConfigData config;
  final AppState app;
  const _Hero({required this.config, required this.app});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(18, 14, 18, 6),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.maroon,
        borderRadius: BorderRadius.circular(22),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('UIS · 2026',
              style: TextStyle(
                  color: Colors.white70,
                  fontSize: 10.5,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.4)),
          const SizedBox(height: 8),
          Text(app.t('heroTitle'),
              style: const TextStyle(
                  color: Colors.white, fontSize: 19, fontWeight: FontWeight.w800, height: 1.35)),
          const SizedBox(height: 8),
          Text(app.t('heroDesc'),
              style: const TextStyle(color: Colors.white70, fontSize: 12, height: 1.5)),
          const SizedBox(height: 16),
          Row(
            children: [
              _stat(config.studentsCount.isEmpty ? '—' : config.studentsCount, app.t('students')),
              const SizedBox(width: 18),
              _stat('${config.collegesCount}', app.t('colleges')),
              const SizedBox(width: 18),
              _stat('${config.departmentsCount}', app.t('depts')),
            ],
          ),
        ],
      ),
    );
  }

  Widget _stat(String n, String label) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(n,
            style: const TextStyle(
                color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800)),
        Text(label, style: const TextStyle(color: Colors.white60, fontSize: 10)),
      ],
    );
  }
}

class _QuickActionsGrid extends StatelessWidget {
  final AppState app;
  const _QuickActionsGrid({required this.app});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('news', app.t('quickNews'), () => const NewsScreen()),
      ('events', app.t('quickEvents'), () => const EventsScreen()),
      ('services', app.t('quickServices'), () => const ServicesScreen()),
      ('college', app.t('quickColleges'), () => const CollegesScreen()),
      ('directory', app.t('quickDirectory'), () => const DirectoryScreen()),
      ('map', app.t('quickMap'), () => const MapScreen()),
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 4),
      child: GridView.count(
        crossAxisCount: 3,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 0.95,
        children: items.map((it) {
          return InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => it.$3()),
            ),
            child: Container(
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? AppColors.darkLine
                      : AppColors.line,
                ),
              ),
              alignment: Alignment.center,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircleAvatar(
                    radius: 19,
                    backgroundColor: AppColors.maroon,
                    child: Icon(iconForKey(it.$1), color: Colors.white, size: 17),
                  ),
                  const SizedBox(height: 8),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: Text(it.$2,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

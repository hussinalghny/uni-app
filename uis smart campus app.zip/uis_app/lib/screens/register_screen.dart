import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../services/api_service.dart';
import '../services/notification_service.dart';
import 'login_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _studentNumberCtrl = TextEditingController();
  bool _loading = false;
  String? _error;

  Future<void> _submit() async {
    final app = context.read<AppState>();
    if (_nameCtrl.text.trim().isEmpty ||
        _emailCtrl.text.trim().isEmpty ||
        _passwordCtrl.text.length < 8) {
      setState(() => _error = app.isArabic
          ? 'تأكد من الاسم والبريد، وكلمة المرور 8 أحرف فأكثر'
          : 'Check name/email, and password must be 8+ characters');
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final (token, student) = await ApiService().register(
        name: _nameCtrl.text.trim(),
        email: _emailCtrl.text.trim(),
        password: _passwordCtrl.text,
        phone: _phoneCtrl.text.trim(),
        studentNumber: _studentNumberCtrl.text.trim(),
      );
      await app.setSession(token, student);
      await NotificationService.instance.refreshTokenLink();
      if (!mounted) return;
      Navigator.of(context).pop();
    } catch (e) {
      setState(() {
        _loading = false;
        _error = e.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(app.t('createAccount'))),
      body: ListView(
        padding: const EdgeInsets.all(22),
        children: [
          if (_error != null) ...[
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.danger.withOpacity(0.08),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(_error!, style: const TextStyle(color: AppColors.danger, fontSize: 12.5)),
            ),
            const SizedBox(height: 14),
          ],
          TextField(controller: _nameCtrl, decoration: InputDecoration(labelText: app.t('fullNameLabel'))),
          const SizedBox(height: 12),
          TextField(
            controller: _emailCtrl,
            keyboardType: TextInputType.emailAddress,
            decoration: InputDecoration(labelText: app.t('emailLabel')),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _passwordCtrl,
            obscureText: true,
            decoration: InputDecoration(labelText: app.t('passwordLabel')),
          ),
          const SizedBox(height: 12),
          TextField(controller: _phoneCtrl, decoration: InputDecoration(labelText: app.t('phoneOptional'))),
          const SizedBox(height: 12),
          TextField(
              controller: _studentNumberCtrl,
              decoration: InputDecoration(labelText: app.t('studentNumberOptional'))),
          const SizedBox(height: 22),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.maroon),
            onPressed: _loading ? null : _submit,
            child: _loading
                ? const SizedBox(
                    width: 18, height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : Text(app.t('createAccount')),
          ),
          const SizedBox(height: 16),
          Center(
            child: TextButton(
              onPressed: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const LoginScreen()),
              ),
              child: Text('${app.t('alreadyHaveAccount')} ${app.t('login')}'),
            ),
          ),
        ],
      ),
    );
  }
}

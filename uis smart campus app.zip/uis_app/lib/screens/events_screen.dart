import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../models/event_item.dart';
import '../services/api_service.dart';
import '../widgets/async_view.dart';
import '../widgets/event_card.dart';
import '../widgets/empty_state.dart';
import 'event_detail_screen.dart';

const _eventCategories = [
  'all',
  'ev_cat_conf',
  'ev_cat_sem',
  'ev_cat_ws',
  'ev_cat_course',
  'ev_cat_comp',
  'ev_cat_uni',
];

class EventsScreen extends StatefulWidget {
  const EventsScreen({super.key});

  @override
  State<EventsScreen> createState() => _EventsScreenState();
}

class _EventsScreenState extends State<EventsScreen> {
  final _api = ApiService();
  String _category = 'all';
  Key _listKey = UniqueKey();

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(app.t('events'))),
      body: Column(
        children: [
          SizedBox(
            height: 44,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 6),
              itemCount: _eventCategories.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, i) {
                final c = _eventCategories[i];
                final selected = c == _category;
                return ChoiceChip(
                  label: Text(c == 'all' ? app.t('all') : app.t(c)),
                  selected: selected,
                  onSelected: (_) {
                    setState(() {
                      _category = c;
                      _listKey = UniqueKey();
                    });
                  },
                  showCheckmark: false,
                  backgroundColor: Colors.transparent,
                  selectedColor: Theme.of(context).cardColor,
                  side: BorderSide.none,
                  elevation: selected ? 1 : 0,
                  labelStyle: TextStyle(
                    color: selected ? AppColors.maroon : AppColors.muted,
                    fontSize: 12,
                    fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                  ),
                );
              },
            ),
          ),
          Expanded(
            child: AsyncView<List<EventItem>>(
              key: _listKey,
              loader: () => _api.getEvents(category: _category),
              isEmpty: (d) => d.isEmpty,
              emptyBuilder: (_) => EmptyState(
                icon: Icons.event_busy_outlined,
                title: app.t('emptyEvents'),
                description: app.t('noResultsDesc'),
              ),
              builder: (context, items) => ListView.builder(
                padding: const EdgeInsets.only(top: 8, bottom: 24),
                itemCount: items.length,
                itemBuilder: (context, i) {
                  final e = items[i];
                  return EventCard(
                    item: e,
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => EventDetailScreen(id: e.id)),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../core/icon_map.dart';
import '../models/college_item.dart';
import '../services/api_service.dart';
import '../widgets/async_view.dart';

class CollegeDetailScreen extends StatelessWidget {
  final int id;
  const CollegeDetailScreen({super.key, required this.id});

  Future<void> _launch(String scheme, String value) async {
    final uri = Uri.parse('$scheme:$value');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final api = ApiService();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(title: Text(app.t('collegesTitle'))),
      body: AsyncView<CollegeItem>(
        loader: () => api.getCollegeDetail(id),
        builder: (context, item) {
          return ListView(
            padding: const EdgeInsets.all(18),
            children: [
              CircleAvatar(
                radius: 28,
                backgroundColor: AppColors.maroon,
                child: Icon(iconForKey(item.icon), color: Colors.white, size: 24),
              ),
              const SizedBox(height: 14),
              Text(item.name(app.isArabic),
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              if (item.about(app.isArabic) != null) ...[
                const SizedBox(height: 12),
                Text(app.t('about'), style: const TextStyle(fontSize: 11, color: AppColors.muted)),
                const SizedBox(height: 6),
                Text(item.about(app.isArabic)!, style: const TextStyle(fontSize: 13, height: 1.8)),
              ],
              if (item.departments.isNotEmpty) ...[
                const SizedBox(height: 20),
                Text(app.t('departments'),
                    style: const TextStyle(fontSize: 11, color: AppColors.muted)),
                const SizedBox(height: 8),
                ...item.departments.map((d) => Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardColor,
                        borderRadius: BorderRadius.circular(12),
                        border:
                            Border.all(color: isDark ? AppColors.darkLine : AppColors.line),
                      ),
                      child: Row(
                        children: [
                          Icon(iconForKey('college'), size: 16, color: AppColors.maroon),
                          const SizedBox(width: 10),
                          Text(d.name(app.isArabic),
                              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5)),
                        ],
                      ),
                    )),
              ],
              const SizedBox(height: 20),
              Text(app.t('contactInfo'), style: const TextStyle(fontSize: 11, color: AppColors.muted)),
              const SizedBox(height: 8),
              Container(
                decoration: BoxDecoration(
                  color: Theme.of(context).cardColor,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: isDark ? AppColors.darkLine : AppColors.line),
                ),
                child: Column(
                  children: [
                    if (item.email != null)
                      _infoTile(context, Icons.mail_outline, item.email!,
                          app.t('email'), () => _launch('mailto', item.email!)),
                    if (item.phone != null)
                      _infoTile(context, Icons.call_outlined, item.phone!,
                          app.t('phone'), () => _launch('tel', item.phone!)),
                    if (item.location(app.isArabic) != null)
                      _infoTile(context, Icons.place_outlined, item.location(app.isArabic)!,
                          app.t('location'), null),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _infoTile(
      BuildContext context, IconData icon, String value, String label, VoidCallback? onTap) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Row(
          children: [
            CircleAvatar(
              radius: 16,
              backgroundColor: AppColors.cream2,
              child: Icon(icon, size: 15, color: AppColors.maroon),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(value, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5)),
                  Text(label, style: const TextStyle(fontSize: 10.5, color: AppColors.muted)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

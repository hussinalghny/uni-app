import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import 'notifications_screen.dart';
import 'voice_screen.dart';
import 'settings_screen.dart';
import 'my_requests_screen.dart';
import 'login_screen.dart';
import 'registration_webview_screen.dart';

class AccountScreen extends StatelessWidget {
  const AccountScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(title: Text(app.t('myAccount'))),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Center(
            child: Column(
              children: [
                CircleAvatar(
                  radius: 34,
                  backgroundColor: AppColors.maroon,
                  child: Text(
                    app.isLoggedIn
                        ? (app.student!.name.isNotEmpty ? app.student!.name[0].toUpperCase() : '?')
                        : (app.isArabic ? 'ط' : 'G'),
                    style: const TextStyle(
                        color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800),
                  ),
                ),
                const SizedBox(height: 12),
                Text(app.isLoggedIn ? app.student!.name : app.t('guestUser'),
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                if (app.isLoggedIn) ...[
                  const SizedBox(height: 4),
                  Text(app.student!.email,
                      style: const TextStyle(fontSize: 11.5, color: AppColors.muted)),
                ] else ...[
                  const SizedBox(height: 4),
                  Text(app.t('loginToContinue'),
                      style: const TextStyle(fontSize: 11.5, color: AppColors.muted)),
                ],
                const SizedBox(height: 14),
                if (!app.isLoggedIn)
                  FilledButton(
                    style: FilledButton.styleFrom(
                        backgroundColor: AppColors.maroon,
                        padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 11)),
                    onPressed: () => Navigator.of(context)
                        .push(MaterialPageRoute(builder: (_) => const LoginScreen())),
                    child: Text(app.t('login')),
                  )
                else
                  OutlinedButton(
                    onPressed: () => app.logout(),
                    child: Text(app.t('logout')),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Text(app.t('quickActions'),
              style: const TextStyle(fontSize: 11, color: AppColors.muted, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          _tile(context, Icons.how_to_reg_outlined, app.t('registration'),
              () => const RegistrationWebViewScreen(), isDark),
          _tile(context, Icons.notifications_none_outlined, app.t('notifTitle'),
              () => const NotificationsScreen(), isDark),
          _tile(context, Icons.record_voice_over_outlined, app.t('voiceTitle'),
              () => const VoiceScreen(), isDark),
          _tile(context, Icons.receipt_long_outlined, app.t('myRequests'),
              () => const MyRequestsScreen(), isDark),
          _tile(context, Icons.settings_outlined, app.t('settingsTitle'),
              () => const SettingsScreen(), isDark),
        ],
      ),
    );
  }

  Widget _tile(BuildContext context, IconData icon, String label, Widget Function() page, bool isDark) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => page())),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: isDark ? AppColors.darkLine : AppColors.line),
          ),
          child: Row(
            children: [
              CircleAvatar(
                backgroundColor: AppColors.maroon,
                child: Icon(icon, color: Colors.white, size: 17),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
              ),
              const Icon(Icons.chevron_left, color: AppColors.muted),
            ],
          ),
        ),
      ),
    );
  }
}

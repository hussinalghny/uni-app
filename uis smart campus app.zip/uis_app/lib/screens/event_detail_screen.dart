import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../core/date_utils.dart';
import '../models/event_item.dart';
import '../services/api_service.dart';
import '../widgets/async_view.dart';
import '../widgets/net_image.dart';

class EventDetailScreen extends StatefulWidget {
  final int id;
  const EventDetailScreen({super.key, required this.id});

  @override
  State<EventDetailScreen> createState() => _EventDetailScreenState();
}

class _EventDetailScreenState extends State<EventDetailScreen> {
  final _api = ApiService();
  bool _registered = false;
  bool _submitting = false;

  Future<void> _openRegisterSheet(EventItem item) async {
    final app = context.read<AppState>();
    final nameCtrl = TextEditingController();
    final emailCtrl = TextEditingController();
    final phoneCtrl = TextEditingController();

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetCtx) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(sheetCtx).viewInsets.bottom,
            left: 18,
            right: 18,
            top: 18,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(app.t('registerEvent'),
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
              const SizedBox(height: 14),
              TextField(
                controller: nameCtrl,
                decoration: InputDecoration(labelText: app.t('fullName')),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: emailCtrl,
                decoration: InputDecoration(labelText: app.t('email')),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: phoneCtrl,
                decoration: InputDecoration(labelText: app.t('phoneNumber')),
              ),
              const SizedBox(height: 18),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: AppColors.maroon),
                onPressed: () async {
                  if (nameCtrl.text.trim().isEmpty) return;
                  Navigator.pop(sheetCtx);
                  setState(() => _submitting = true);
                  try {
                    await _api.registerForEvent(
                      item.id,
                      name: nameCtrl.text.trim(),
                      email: emailCtrl.text.trim(),
                      phone: phoneCtrl.text.trim(),
                    );
                    if (!mounted) return;
                    setState(() {
                      _registered = true;
                      _submitting = false;
                    });
                    ScaffoldMessenger.of(context)
                        .showSnackBar(SnackBar(content: Text(app.t('registered'))));
                  } catch (_) {
                    if (!mounted) return;
                    setState(() => _submitting = false);
                    ScaffoldMessenger.of(context)
                        .showSnackBar(SnackBar(content: Text(app.t('networkError'))));
                  }
                },
                child: Text(app.t('submit')),
              ),
              const SizedBox(height: 20),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      body: AsyncView<EventItem>(
        loader: () => _api.getEventDetail(widget.id),
        builder: (context, item) {
          return CustomScrollView(
            slivers: [
              SliverAppBar(
                expandedHeight: 220,
                pinned: true,
                iconTheme: const IconThemeData(color: Colors.white),
                flexibleSpace: FlexibleSpaceBar(
                  background: Stack(
                    fit: StackFit.expand,
                    children: [
                      NetImage(url: item.imageUrl, fallbackIcon: 'events'),
                      Container(color: Colors.black.withOpacity(0.4)),
                    ],
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF3E9D2),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(app.t(item.category),
                            style: const TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w800,
                                color: AppColors.goldDark)),
                      ),
                      const SizedBox(height: 12),
                      Text(item.title(app.isArabic),
                          style: const TextStyle(
                              fontSize: 19, fontWeight: FontWeight.w800, height: 1.4)),
                      const SizedBox(height: 14),
                      _row(Icons.calendar_today_outlined, formatDate(item.eventDate, app.isArabic)),
                      if (item.time(app.isArabic) != null)
                        _row(Icons.access_time, item.time(app.isArabic)!),
                      if (item.place(app.isArabic) != null)
                        _row(Icons.place_outlined, item.place(app.isArabic)!),
                      const SizedBox(height: 16),
                      if (item.description(app.isArabic) != null)
                        Text(item.description(app.isArabic)!,
                            style: const TextStyle(fontSize: 13.5, height: 1.9)),
                      if (item.organizer(app.isArabic) != null) ...[
                        const SizedBox(height: 18),
                        Text(app.t('organizer'),
                            style:
                                const TextStyle(fontSize: 11, color: AppColors.muted)),
                        const SizedBox(height: 4),
                        Text(item.organizer(app.isArabic)!,
                            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                      ],
                      const SizedBox(height: 22),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          style: FilledButton.styleFrom(
                            backgroundColor: _registered ? AppColors.ok : AppColors.gold,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                          onPressed: (_registered || _submitting)
                              ? null
                              : () => _openRegisterSheet(item),
                          icon: Icon(_registered ? Icons.check : Icons.event_available_outlined),
                          label: Text(_registered ? app.t('registered') : app.t('registerEvent')),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _row(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Icon(icon, size: 15, color: AppColors.muted),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 12.5))),
        ],
      ),
    );
  }
}

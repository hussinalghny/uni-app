import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../core/icon_map.dart';
import '../services/api_service.dart';
import '../widgets/async_view.dart';
import '../widgets/empty_state.dart';
import '../widgets/news_card.dart';
import '../widgets/event_card.dart';
import 'news_detail_screen.dart';
import 'event_detail_screen.dart';
import 'college_detail_screen.dart';
import 'service_detail_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _api = ApiService();
  final _controller = TextEditingController();
  String _query = '';
  Key _key = UniqueKey();

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _controller,
          autofocus: true,
          onSubmitted: (v) => setState(() {
            _query = v;
            _key = UniqueKey();
          }),
          style: const TextStyle(color: AppColors.ink, fontSize: 14),
          decoration: InputDecoration(
            hintText: app.t('searchPlaceholder'),
            hintStyle: const TextStyle(color: AppColors.muted),
            border: InputBorder.none,
            filled: false,
          ),
        ),
      ),
      body: _query.isEmpty
          ? EmptyState(icon: Icons.search, title: app.t('searchPlaceholder'))
          : AsyncView<SearchResults>(
              key: _key,
              loader: () => _api.search(_query),
              isEmpty: (d) => d.isEmpty,
              emptyBuilder: (_) => EmptyState(
                icon: Icons.search_off,
                title: app.t('noResults'),
                description: app.t('noResultsDesc'),
              ),
              builder: (context, results) => ListView(
                padding: const EdgeInsets.symmetric(vertical: 12),
                children: [
                  if (results.colleges.isNotEmpty) ...[
                    _sectionLabel(app.t('collegesTitle')),
                    ...results.colleges.map((c) => ListTile(
                          leading: CircleAvatar(
                            backgroundColor: AppColors.cream2,
                            child: Icon(iconForKey(c.icon), color: AppColors.maroon, size: 17),
                          ),
                          title: Text(c.name(app.isArabic)),
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => CollegeDetailScreen(id: c.id)),
                          ),
                        )),
                  ],
                  if (results.news.isNotEmpty) ...[
                    _sectionLabel(app.t('news')),
                    ...results.news.map((n) => ListTile(
                          leading: Icon(iconForKey('news'), color: AppColors.maroon),
                          title: Text(n.title(app.isArabic), maxLines: 2),
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => NewsDetailScreen(id: n.id)),
                          ),
                        )),
                  ],
                  if (results.events.isNotEmpty) ...[
                    _sectionLabel(app.t('events')),
                    ...results.events.map((e) => EventCard(
                          item: e,
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => EventDetailScreen(id: e.id)),
                          ),
                        )),
                  ],
                  if (results.services.isNotEmpty) ...[
                    _sectionLabel(app.t('servicesTitle')),
                    ...results.services.map((s) => ListTile(
                          leading: CircleAvatar(
                            backgroundColor: AppColors.cream2,
                            child: Icon(iconForKey(s.icon), color: AppColors.maroon, size: 17),
                          ),
                          title: Text(s.name(app.isArabic)),
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => ServiceDetailScreen(id: s.id)),
                          ),
                        )),
                  ],
                ],
              ),
            ),
    );
  }

  Widget _sectionLabel(String text) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 6),
        child: Text(text,
            style: const TextStyle(
                fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.muted)),
      );
}

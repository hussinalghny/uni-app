import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../core/icon_map.dart';
import '../models/service_item.dart';
import '../services/api_service.dart';
import '../widgets/async_view.dart';
import '../widgets/empty_state.dart';
import 'service_detail_screen.dart';

class ServicesScreen extends StatelessWidget {
  const ServicesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final api = ApiService();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(title: Text(app.t('servicesTitle'))),
      body: AsyncView<List<ServiceItem>>(
        loader: () => api.getServices(),
        isEmpty: (d) => d.isEmpty,
        emptyBuilder: (_) => EmptyState(
          icon: Icons.stars_outlined,
          title: app.t('emptyServices'),
          description: app.t('noResultsDesc'),
        ),
        builder: (context, items) => GridView.builder(
          padding: const EdgeInsets.all(18),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 0.9,
          ),
          itemCount: items.length,
          itemBuilder: (context, i) {
            final s = items[i];
            return InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => ServiceDetailScreen(id: s.id)),
              ),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Theme.of(context).cardColor,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: isDark ? AppColors.darkLine : AppColors.line),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(
                      radius: 19,
                      backgroundColor: AppColors.maroon,
                      child: Icon(iconForKey(s.icon), color: Colors.white, size: 17),
                    ),
                    const Spacer(),
                    Text(s.name(app.isArabic),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5)),
                    if (s.description(app.isArabic) != null) ...[
                      const SizedBox(height: 4),
                      Text(s.description(app.isArabic)!,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 10.5, color: AppColors.muted)),
                    ],
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

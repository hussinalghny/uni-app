import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../services/api_service.dart';
import '../services/my_requests_store.dart';
import '../widgets/empty_state.dart';

class MyRequestsScreen extends StatefulWidget {
  const MyRequestsScreen({super.key});

  @override
  State<MyRequestsScreen> createState() => _MyRequestsScreenState();
}

class _MyRequestsScreenState extends State<MyRequestsScreen> {
  final _api = ApiService();
  final _numberCtrl = TextEditingController();
  String _lookupKind = 'service';
  List<SavedRequest> _saved = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadSaved();
  }

  Future<void> _loadSaved() async {
    final list = await MyRequestsStore.load();
    if (mounted) setState(() {
      _saved = list;
      _loading = false;
    });
  }

  Future<void> _lookupManual() async {
    final number = _numberCtrl.text.trim();
    if (number.isEmpty) return;
    final app = context.read<AppState>();
    try {
      final data = _lookupKind == 'service'
          ? await _api.trackServiceRequest(number)
          : await _api.trackVoiceTicket(number);
      if (!mounted) return;
      await MyRequestsStore.add(_lookupKind, number);
      _numberCtrl.clear();
      await _loadSaved();
      _showStatusSheet(_lookupKind, number, data);
    } catch (e) {
      if (!mounted) return;
      final isNetwork = e is ApiException && e.message == 'network';
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(isNetwork ? app.t('networkError') : app.t('requestNotFound')),
      ));
    }
  }

  Future<void> _openSaved(SavedRequest r) async {
    final app = context.read<AppState>();
    try {
      final data = r.kind == 'service'
          ? await _api.trackServiceRequest(r.number)
          : await _api.trackVoiceTicket(r.number);
      if (!mounted) return;
      _showStatusSheet(r.kind, r.number, data);
    } catch (e) {
      if (!mounted) return;
      final isNetwork = e is ApiException && e.message == 'network';
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(isNetwork ? app.t('networkError') : app.t('requestNotFound')),
      ));
    }
  }

  void _showStatusSheet(String kind, String number, Map<String, dynamic> data) {
    final app = context.read<AppState>();
    final status = data['status']?.toString() ?? '';
    final label = kind == 'service'
        ? (app.isArabic ? data['service_name_ar'] : data['service_name_en'])
        : app.t(data['type']?.toString() ?? '');
    final reply = data['admin_reply']?.toString();
    final replyFileUrl = data['admin_reply_file_url']?.toString();

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetCtx) => Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(number,
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
            if (label != null) ...[
              const SizedBox(height: 6),
              Text(label, style: const TextStyle(color: AppColors.muted, fontSize: 12.5)),
            ],
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: AppColors.cream2,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(app.t('status_$status'),
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5)),
            ),
            if (reply != null && reply.trim().isNotEmpty) ...[
              const SizedBox(height: 16),
              Text(app.t('adminReply'),
                  style: const TextStyle(fontSize: 11, color: AppColors.muted, fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.maroon.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(reply, style: const TextStyle(fontSize: 12.5, height: 1.6)),
              ),
            ],
            if (replyFileUrl != null && replyFileUrl.isNotEmpty) ...[
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: () async {
                  final uri = Uri.parse(replyFileUrl);
                  if (await canLaunchUrl(uri)) {
                    await launchUrl(uri, mode: LaunchMode.externalApplication);
                  }
                },
                icon: const Icon(Icons.attach_file, size: 16),
                label: Text(app.t('viewAttachedFile')),
              ),
            ],
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: () async {
                  await MyRequestsStore.remove(number);
                  Navigator.pop(sheetCtx);
                  _loadSaved();
                },
                child: Text(app.t('remove')),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(title: Text(app.t('myRequests'))),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(app.t('myRequestsDesc'),
              style: const TextStyle(fontSize: 12, color: AppColors.ink2)),
          const SizedBox(height: 16),
          Text(app.t('trackByNumber'),
              style: const TextStyle(fontSize: 11, color: AppColors.muted)),
          const SizedBox(height: 8),
          SegmentedButton<String>(
            segments: [
              ButtonSegment(value: 'service', label: Text(app.t('serviceRequest'))),
              ButtonSegment(value: 'voice', label: Text(app.t('voiceTicket'))),
            ],
            selected: {_lookupKind},
            onSelectionChanged: (s) => setState(() => _lookupKind = s.first),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _numberCtrl,
                  decoration: InputDecoration(hintText: app.t('enterNumber')),
                ),
              ),
              const SizedBox(width: 8),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: AppColors.maroon),
                onPressed: _lookupManual,
                child: Text(app.t('submit')),
              ),
            ],
          ),
          const SizedBox(height: 22),
          if (!_loading && _saved.isEmpty)
            EmptyState(icon: Icons.receipt_long_outlined, title: app.t('noSavedRequests')),
          ..._saved.map((r) => Container(
                margin: const EdgeInsets.only(bottom: 10),
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => _openSaved(r),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Theme.of(context).cardColor,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: isDark ? AppColors.darkLine : AppColors.line),
                    ),
                    child: Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: AppColors.cream2,
                          child: Icon(
                            r.kind == 'service'
                                ? Icons.description_outlined
                                : Icons.record_voice_over_outlined,
                            color: AppColors.maroon,
                            size: 17,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(r.number,
                                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
                              Text(
                                r.kind == 'service' ? app.t('serviceRequest') : app.t('voiceTicket'),
                                style: const TextStyle(fontSize: 10.5, color: AppColors.muted),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_left, color: AppColors.muted),
                      ],
                    ),
                  ),
                ),
              )),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import '../core/app_colors.dart';
import 'main_shell.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1100), () {
      if (mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const MainShell()),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.maroonDark,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset(
              'assets/images/logo.png',
              width: 120,
              height: 120,
            ),
            const SizedBox(height: 18),
            const Text('جامعة العلوم العراقية',
                style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 18),
            const SizedBox(
              width: 30,
              height: 30,
              child: CircularProgressIndicator(color: AppColors.gold, strokeWidth: 3),
            ),
          ],
        ),
      ),
    );
  }
}

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../core/icon_map.dart';
import '../services/api_service.dart';
import '../services/my_requests_store.dart';

class VoiceScreen extends StatefulWidget {
  const VoiceScreen({super.key});

  @override
  State<VoiceScreen> createState() => _VoiceScreenState();
}

class _VoiceScreenState extends State<VoiceScreen> {
  final _api = ApiService();
  String _type = 'complaint';
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _messageCtrl = TextEditingController();
  File? _attachment;
  bool _submitting = false;

  Future<void> _pickFile() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (picked != null) setState(() => _attachment = File(picked.path));
  }

  Future<void> _submit() async {
    final app = context.read<AppState>();
    if (_nameCtrl.text.trim().isEmpty || _messageCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(app.t('required'))));
      return;
    }
    setState(() => _submitting = true);
    try {
      final ticket = await _api.submitVoiceRequest(
        type: _type,
        name: _nameCtrl.text.trim(),
        email: _emailCtrl.text.trim(),
        phone: _phoneCtrl.text.trim(),
        message: _messageCtrl.text.trim(),
        attachment: _attachment,
      );
      if (!mounted) return;
      setState(() => _submitting = false);
      if (ticket.isNotEmpty) {
        await MyRequestsStore.add('voice', ticket);
      }
      _showSuccess(ticket);
    } catch (_) {
      if (!mounted) return;
      setState(() => _submitting = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(app.t('networkError'))));
    }
  }

  void _showSuccess(String ticket) {
    final app = context.read<AppState>();
    showDialog(
      context: context,
      builder: (dialogCtx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircleAvatar(
              radius: 26,
              backgroundColor: AppColors.gold,
              child: const Icon(Icons.check, color: Colors.white),
            ),
            const SizedBox(height: 14),
            Text(app.t('submitSuccess'),
                textAlign: TextAlign.center,
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
            const SizedBox(height: 8),
            Text(app.t('submitSuccessDesc'),
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: AppColors.muted)),
            if (ticket.isNotEmpty) ...[
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
                decoration:
                    BoxDecoration(color: AppColors.cream2, borderRadius: BorderRadius.circular(10)),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(ticket, style: const TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(width: 8),
                    InkWell(
                      borderRadius: BorderRadius.circular(6),
                      onTap: () {
                        Clipboard.setData(ClipboardData(text: ticket));
                        ScaffoldMessenger.of(context)
                            .showSnackBar(SnackBar(content: Text(app.t('copied'))));
                      },
                      child: const Icon(Icons.copy_outlined, size: 16, color: AppColors.maroon),
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                style: FilledButton.styleFrom(backgroundColor: AppColors.maroon),
                onPressed: () {
                  Navigator.pop(dialogCtx);
                  setState(() {
                    _nameCtrl.clear();
                    _emailCtrl.clear();
                    _phoneCtrl.clear();
                    _messageCtrl.clear();
                    _attachment = null;
                  });
                },
                child: Text(app.t('close')),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final types = [
      ('complaint', 'voice'),
      ('suggestion', 'tag'),
      ('inquiry', 'help'),
      ('report', 'admin_link'),
    ];

    return Scaffold(
      appBar: AppBar(title: Text(app.t('voiceTitle'))),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(app.t('voiceDesc'), style: const TextStyle(fontSize: 12.5, color: AppColors.ink2)),
          const SizedBox(height: 16),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.6,
            children: types.map((t) {
              final selected = _type == t.$1;
              return InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => setState(() => _type = t.$1),
                child: Container(
                  decoration: BoxDecoration(
                    color: selected ? AppColors.maroon.withOpacity(0.08) : null,
                    border: Border.all(
                        color: selected ? AppColors.maroon : AppColors.line, width: selected ? 2 : 1.2),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  alignment: Alignment.center,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(iconForKey(t.$2), color: AppColors.maroon, size: 20),
                      const SizedBox(height: 6),
                      Text(app.t(t.$1),
                          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 18),
          TextField(controller: _nameCtrl, decoration: InputDecoration(labelText: app.t('fullName'))),
          const SizedBox(height: 10),
          TextField(controller: _emailCtrl, decoration: InputDecoration(labelText: app.t('email'))),
          const SizedBox(height: 10),
          TextField(
              controller: _phoneCtrl, decoration: InputDecoration(labelText: app.t('phoneNumber'))),
          const SizedBox(height: 10),
          TextField(
            controller: _messageCtrl,
            maxLines: 4,
            decoration: InputDecoration(labelText: app.t('message')),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: _pickFile,
            icon: const Icon(Icons.attach_file, size: 16),
            label: Text(_attachment != null ? app.t('fileAttached') : app.t('chooseFile')),
          ),
          const SizedBox(height: 18),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: AppColors.maroon,
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              onPressed: _submitting ? null : _submit,
              child: _submitting
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : Text(app.t('send')),
            ),
          ),
        ],
      ),
    );
  }
}

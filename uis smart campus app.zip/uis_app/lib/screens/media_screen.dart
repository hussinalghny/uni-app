import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../models/media_item_model.dart';
import '../services/api_service.dart';
import '../widgets/async_view.dart';
import '../widgets/net_image.dart';
import '../widgets/empty_state.dart';

class MediaScreen extends StatefulWidget {
  const MediaScreen({super.key});

  @override
  State<MediaScreen> createState() => _MediaScreenState();
}

class _MediaScreenState extends State<MediaScreen> {
  final _api = ApiService();
  String _type = 'photo';

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(app.t('mediaTitle'))),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 6),
            child: Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: AppColors.cream2,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  _tab('photo', app.t('photos')),
                  _tab('video', app.t('videos')),
                  _tab('album', app.t('albums')),
                ],
              ),
            ),
          ),
          Expanded(
            child: AsyncView<List<MediaItemModel>>(
              key: ValueKey(_type),
              loader: () => _api.getMedia(type: _type),
              isEmpty: (d) => d.isEmpty,
              emptyBuilder: (_) => EmptyState(
                icon: Icons.perm_media_outlined,
                title: app.t('noResults'),
              ),
              builder: (context, items) => GridView.builder(
                padding: const EdgeInsets.all(18),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 6,
                  mainAxisSpacing: 6,
                ),
                itemCount: items.length,
                itemBuilder: (context, i) {
                  final m = items[i];
                  return ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        NetImage(url: m.fileUrl, fallbackIcon: 'media'),
                        if (_type == 'video')
                          Container(
                            color: Colors.black26,
                            alignment: Alignment.center,
                            child: const Icon(Icons.play_circle_outline,
                                color: Colors.white, size: 26),
                          ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _tab(String type, String label) {
    final selected = _type == type;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _type = type),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 9),
          decoration: BoxDecoration(
            color: selected ? Theme.of(context).cardColor : Colors.transparent,
            borderRadius: BorderRadius.circular(9),
            boxShadow: selected
                ? const [BoxShadow(color: Colors.black12, blurRadius: 4)]
                : null,
          ),
          alignment: Alignment.center,
          child: Text(label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: selected ? AppColors.maroon : AppColors.muted,
              )),
        ),
      ),
    );
  }
}

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../core/icon_map.dart';
import '../models/service_item.dart';
import '../services/api_service.dart';
import '../services/my_requests_store.dart';
import '../widgets/async_view.dart';

class ServiceDetailScreen extends StatelessWidget {
  final int id;
  const ServiceDetailScreen({super.key, required this.id});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final api = ApiService();
    return Scaffold(
      appBar: AppBar(title: Text(app.t('servicesTitle'))),
      body: AsyncView<ServiceItem>(
        loader: () => api.getServiceDetail(id),
        builder: (context, item) => _ServiceDetailBody(item: item, api: api),
      ),
    );
  }
}

class _ServiceDetailBody extends StatefulWidget {
  final ServiceItem item;
  final ApiService api;
  const _ServiceDetailBody({required this.item, required this.api});

  @override
  State<_ServiceDetailBody> createState() => _ServiceDetailBodyState();
}

class _ServiceDetailBodyState extends State<_ServiceDetailBody> {
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  File? _attachment;
  bool _submitting = false;

  Future<void> _pickFile() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() => _attachment = File(picked.path));
    }
  }

  Future<void> _submit() async {
    final app = context.read<AppState>();
    if (_nameCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(app.t('required'))));
      return;
    }
    setState(() => _submitting = true);
    try {
      final requestNumber = await widget.api.submitServiceRequest(
        widget.item.id,
        name: _nameCtrl.text.trim(),
        email: _emailCtrl.text.trim(),
        phone: _phoneCtrl.text.trim(),
        attachment: _attachment,
      );
      if (!mounted) return;
      setState(() => _submitting = false);
      if (requestNumber.isNotEmpty) {
        await MyRequestsStore.add('service', requestNumber);
      }
      _showSuccess(requestNumber);
    } catch (_) {
      if (!mounted) return;
      setState(() => _submitting = false);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(app.t('networkError'))));
    }
  }

  void _showSuccess(String requestNumber) {
    final app = context.read<AppState>();
    showDialog(
      context: context,
      builder: (dialogCtx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircleAvatar(
              radius: 26,
              backgroundColor: AppColors.gold,
              child: const Icon(Icons.check, color: Colors.white),
            ),
            const SizedBox(height: 14),
            Text(app.t('submitSuccess'),
                textAlign: TextAlign.center,
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
            const SizedBox(height: 8),
            Text(app.t('submitSuccessDesc'),
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: AppColors.muted)),
            if (requestNumber.isNotEmpty) ...[
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
                decoration: BoxDecoration(
                  color: AppColors.cream2,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(requestNumber,
                        style: const TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1)),
                    const SizedBox(width: 8),
                    InkWell(
                      borderRadius: BorderRadius.circular(6),
                      onTap: () {
                        Clipboard.setData(ClipboardData(text: requestNumber));
                        ScaffoldMessenger.of(context)
                            .showSnackBar(SnackBar(content: Text(app.t('copied'))));
                      },
                      child: const Icon(Icons.copy_outlined, size: 16, color: AppColors.maroon),
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                style: FilledButton.styleFrom(backgroundColor: AppColors.maroon),
                onPressed: () {
                  Navigator.pop(dialogCtx);
                  Navigator.pop(context);
                },
                child: Text(app.t('close')),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final item = widget.item;
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        CircleAvatar(
          radius: 26,
          backgroundColor: AppColors.maroon,
          child: Icon(iconForKey(item.icon), color: Colors.white, size: 22),
        ),
        const SizedBox(height: 14),
        Text(item.name(app.isArabic),
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        if (item.description(app.isArabic) != null) ...[
          const SizedBox(height: 8),
          Text(item.description(app.isArabic)!, style: const TextStyle(fontSize: 13, height: 1.7)),
        ],
        if (item.requirements(app.isArabic).isNotEmpty) ...[
          const SizedBox(height: 18),
          Text(app.t('requirements'),
              style: const TextStyle(fontSize: 11, color: AppColors.muted)),
          const SizedBox(height: 8),
          ...item.requirements(app.isArabic).map((r) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.check_circle_outline, size: 15, color: AppColors.gold),
                    const SizedBox(width: 8),
                    Expanded(child: Text(r, style: const TextStyle(fontSize: 12.5))),
                  ],
                ),
              )),
        ],
        if (item.steps(app.isArabic).isNotEmpty) ...[
          const SizedBox(height: 12),
          Text(app.t('steps'), style: const TextStyle(fontSize: 11, color: AppColors.muted)),
          const SizedBox(height: 8),
          ...item.steps(app.isArabic).asMap().entries.map((e) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(
                      radius: 11,
                      backgroundColor: AppColors.cream2,
                      child: Text('${e.key + 1}',
                          style: const TextStyle(
                              fontSize: 10, fontWeight: FontWeight.w800, color: AppColors.maroon)),
                    ),
                    const SizedBox(width: 8),
                    Expanded(child: Text(e.value, style: const TextStyle(fontSize: 12.5))),
                  ],
                ),
              )),
        ],
        if (item.duration(app.isArabic) != null) ...[
          const SizedBox(height: 8),
          Row(
            children: [
              const Icon(Icons.access_time, size: 14, color: AppColors.muted),
              const SizedBox(width: 6),
              Text(item.duration(app.isArabic)!,
                  style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700)),
            ],
          ),
        ],
        const Divider(height: 32),
        Text(app.t('startService'),
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
        const SizedBox(height: 12),
        TextField(
          controller: _nameCtrl,
          decoration: InputDecoration(labelText: app.t('fullName')),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _emailCtrl,
          decoration: InputDecoration(labelText: app.t('email')),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _phoneCtrl,
          decoration: InputDecoration(labelText: app.t('phoneNumber')),
        ),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          onPressed: _pickFile,
          icon: const Icon(Icons.attach_file, size: 16),
          label: Text(_attachment != null ? app.t('fileAttached') : app.t('chooseFile')),
        ),
        const SizedBox(height: 18),
        SizedBox(
          width: double.infinity,
          child: FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: AppColors.maroon,
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
            onPressed: _submitting ? null : _submit,
            child: _submitting
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                  )
                : Text(app.t('send')),
          ),
        ),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../core/icon_map.dart';
import 'home_screen.dart';
import 'news_screen.dart';
import 'events_screen.dart';
import 'services_screen.dart';
import 'colleges_screen.dart';
import 'directory_screen.dart';
import 'map_screen.dart';
import 'media_screen.dart';
import 'contact_screen.dart';
import 'voice_screen.dart';
import 'my_requests_screen.dart';
import 'notifications_screen.dart';
import 'settings_screen.dart';
import 'ai_chat_sheet.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;

  final _screens = const [
    HomeScreen(),
    NewsScreen(),
    EventsScreen(),
    ServicesScreen(),
  ];

  void _openMore() {
    final app = context.read<AppState>();
    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetCtx) {
        final items = [
          ('college', app.t('quickColleges'), () => const CollegesScreen()),
          ('directory', app.t('quickDirectory'), () => const DirectoryScreen()),
          ('map', app.t('quickMap'), () => const MapScreen()),
          ('media', app.t('mediaTitle'), () => const MediaScreen()),
          ('contact', app.t('contactTitle'), () => const ContactScreen()),
          ('voice', app.t('voiceTitle'), () => const VoiceScreen()),
          ('doc', app.t('myRequests'), () => const MyRequestsScreen()),
          ('bell', app.t('notifTitle'), () => const NotificationsScreen()),
          ('globe', app.t('settingsTitle'), () => const SettingsScreen()),
        ];
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 10, 18, 18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 38,
                  height: 4,
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: AppColors.line,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
                GridView.count(
                  crossAxisCount: 3,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 0.95,
                  children: items.map((it) {
                    return InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: () {
                        Navigator.pop(sheetCtx);
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => it.$3()),
                        );
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: Theme.of(context).cardColor,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: AppColors.line),
                        ),
                        alignment: Alignment.center,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            CircleAvatar(
                              radius: 20,
                              backgroundColor: AppColors.maroon,
                              child: Icon(iconForKey(it.$1), color: Colors.white, size: 18),
                            ),
                            const SizedBox(height: 8),
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 4),
                              child: Text(
                                it.$2,
                                textAlign: TextAlign.center,
                                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      body: IndexedStack(index: _index, children: _screens),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.gold,
        onPressed: () => showAiChatSheet(context),
        child: const Icon(Icons.auto_awesome, color: Colors.white),
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          border: Border(top: BorderSide(color: AppColors.line, width: 0.6)),
        ),
        child: NavigationBar(
          selectedIndex: _index,
          onDestinationSelected: (i) {
            if (i == 4) {
              _openMore();
              return;
            }
            setState(() => _index = i);
          },
          destinations: [
            NavigationDestination(icon: const Icon(Icons.home_outlined), label: app.t('home')),
            NavigationDestination(
                icon: const Icon(Icons.newspaper_outlined), label: app.t('news')),
            NavigationDestination(
                icon: const Icon(Icons.event_outlined), label: app.t('events')),
            NavigationDestination(
                icon: const Icon(Icons.stars_outlined), label: app.t('services')),
            NavigationDestination(
                icon: const Icon(Icons.more_horiz), label: app.t('more')),
          ],
        ),
      ),
    );
  }
}

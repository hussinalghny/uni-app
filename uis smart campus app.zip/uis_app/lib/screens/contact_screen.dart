import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../core/icon_map.dart';
import '../models/contact_channel_item.dart';
import '../services/api_service.dart';
import '../widgets/async_view.dart';

class ContactScreen extends StatelessWidget {
  const ContactScreen({super.key});

  Future<void> _open(ContactChannelItem c) async {
    Uri? uri;
    switch (c.type) {
      case 'email':
        uri = Uri.parse('mailto:${c.value}');
        break;
      case 'phone':
        uri = Uri.parse('tel:${c.value}');
        break;
      case 'website':
        uri = Uri.parse(c.value.startsWith('http') ? c.value : 'https://${c.value}');
        break;
      default:
        final v = c.value.startsWith('http') ? c.value : 'https://${c.value}';
        uri = Uri.tryParse(v);
    }
    if (uri != null && await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final api = ApiService();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(title: Text(app.t('contactTitle'))),
      body: AsyncView<List<ContactChannelItem>>(
        loader: () => api.getContacts(),
        builder: (context, items) {
          final main = items.where((c) => !c.isSocial).toList();
          final social = items.where((c) => c.isSocial).toList();
          return ListView(
            padding: const EdgeInsets.all(18),
            children: [
              ...main.map((c) => Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () => _open(c),
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: Theme.of(context).cardColor,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                              color: isDark ? AppColors.darkLine : AppColors.line),
                        ),
                        child: Row(
                          children: [
                            CircleAvatar(
                              backgroundColor: AppColors.maroon,
                              child: Icon(iconForKey(c.icon), color: Colors.white, size: 17),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(c.name(app.isArabic),
                                      style: const TextStyle(
                                          fontWeight: FontWeight.w700, fontSize: 13)),
                                  Text(c.value,
                                      style: const TextStyle(
                                          fontSize: 11, color: AppColors.muted)),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  )),
              if (social.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(app.t('social'), style: const TextStyle(fontSize: 11, color: AppColors.muted)),
                const SizedBox(height: 10),
                GridView.count(
                  crossAxisCount: 4,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  children: social.map((c) {
                    return InkWell(
                      onTap: () => _open(c),
                      borderRadius: BorderRadius.circular(16),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CircleAvatar(
                            radius: 22,
                            backgroundColor: AppColors.maroon,
                            child: Icon(iconForKey(c.icon), color: Colors.white, size: 18),
                          ),
                          const SizedBox(height: 6),
                          Text(c.name(app.isArabic),
                              textAlign: TextAlign.center,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 9.5, fontWeight: FontWeight.w700)),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ],
            ],
          );
        },
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../core/date_utils.dart';
import '../core/icon_map.dart';
import '../models/app_notification_item.dart';
import '../services/api_service.dart';
import '../widgets/async_view.dart';
import '../widgets/empty_state.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final api = ApiService();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(title: Text(app.t('notifTitle'))),
      body: AsyncView<List<AppNotificationItem>>(
        loader: () => api.getNotifications(),
        isEmpty: (d) => d.isEmpty,
        emptyBuilder: (_) => EmptyState(
          icon: Icons.notifications_none_outlined,
          title: app.t('noNotifications'),
        ),
        builder: (context, items) => ListView.separated(
          padding: const EdgeInsets.symmetric(vertical: 6),
          itemCount: items.length,
          separatorBuilder: (_, __) =>
              Divider(height: 1, color: isDark ? AppColors.darkLine : AppColors.line),
          itemBuilder: (context, i) {
            final n = items[i];
            return ListTile(
              leading: CircleAvatar(
                backgroundColor: AppColors.maroon,
                child: Icon(iconForKey(n.type), color: Colors.white, size: 16),
              ),
              title: Text(n.title(app.isArabic),
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (n.description(app.isArabic) != null)
                    Text(n.description(app.isArabic)!, style: const TextStyle(fontSize: 11.5)),
                  const SizedBox(height: 4),
                  Text(formatDate(n.publishedAt, app.isArabic),
                      style: const TextStyle(fontSize: 10, color: AppColors.muted)),
                ],
              ),
              isThreeLine: n.description(app.isArabic) != null,
            );
          },
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../core/icon_map.dart';
import '../models/map_location_item.dart';
import '../services/api_service.dart';
import '../widgets/async_view.dart';
import '../widgets/net_image.dart';

class MapScreen extends StatelessWidget {
  const MapScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final api = ApiService();

    return Scaffold(
      appBar: AppBar(title: Text(app.t('mapTitle'))),
      body: AsyncView<CampusMapData>(
        loader: () => api.getMap(),
        builder: (context, data) {
          if (data.mapImageUrl == null) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(30),
                child: Text(app.t('noResults'), style: const TextStyle(color: AppColors.muted)),
              ),
            );
          }
          return SingleChildScrollView(
            padding: const EdgeInsets.all(18),
            child: AspectRatio(
              aspectRatio: 16 / 11,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    NetImage(url: data.mapImageUrl, fallbackIcon: 'map'),
                    ...data.pins.map((pin) => _PinMarker(pin: pin)),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _PinMarker extends StatelessWidget {
  final MapLocationItem pin;
  const _PinMarker({required this.pin});

  Color _color() {
    switch (pin.colorVariant) {
      case 'turq':
        return AppColors.gold;
      case 'gold':
        return AppColors.goldDark;
      default:
        return AppColors.maroon;
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final left = constraints.maxWidth * (pin.posX / 100) - 14;
        final top = constraints.maxHeight * (pin.posY / 100) - 28;
        return Positioned(
          left: left,
          top: top,
          child: GestureDetector(
            onTap: () => _showPinSheet(context, pin),
            child: Container(
              width: 28,
              height: 28,
              decoration: BoxDecoration(
                color: _color(),
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 2),
                boxShadow: const [
                  BoxShadow(color: Colors.black26, blurRadius: 4, offset: Offset(0, 2)),
                ],
              ),
              child: Icon(iconForKey(pin.icon), color: Colors.white, size: 14),
            ),
          ),
        );
      },
    );
  }

  void _showPinSheet(BuildContext context, MapLocationItem pin) {
    final app = Provider.of<AppState>(context, listen: false);
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: AppColors.cream2,
                  child: Icon(iconForKey(pin.icon), color: AppColors.maroon),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(pin.name(app.isArabic),
                          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                      if (pin.description(app.isArabic) != null)
                        Text(pin.description(app.isArabic)!,
                            style: const TextStyle(fontSize: 11.5, color: AppColors.muted)),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

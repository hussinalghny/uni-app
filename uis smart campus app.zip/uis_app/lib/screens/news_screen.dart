import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../models/news_item.dart';
import '../services/api_service.dart';
import '../widgets/async_view.dart';
import '../widgets/news_card.dart';
import '../widgets/empty_state.dart';
import 'news_detail_screen.dart';

const _categories = [
  'all',
  'news_cat_uni',
  'news_cat_col',
  'news_cat_sci',
  'news_cat_cul',
  'news_cat_sport',
  'news_cat_official',
];

class NewsScreen extends StatefulWidget {
  const NewsScreen({super.key});

  @override
  State<NewsScreen> createState() => _NewsScreenState();
}

class _NewsScreenState extends State<NewsScreen> {
  final _api = ApiService();
  String _category = 'all';
  String _query = '';
  final _searchController = TextEditingController();
  Key _listKey = UniqueKey();

  void _reload() {
    setState(() => _listKey = UniqueKey());
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(
        title: Text(app.t('news')),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(56),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 0, 18, 10),
            child: TextField(
              controller: _searchController,
              onSubmitted: (v) {
                _query = v;
                _reload();
              },
              style: const TextStyle(color: AppColors.ink, fontSize: 13),
              decoration: InputDecoration(
                hintText: app.t('searchNewsPlaceholder'),
                hintStyle: const TextStyle(color: AppColors.muted),
                prefixIcon: const Icon(Icons.search, color: AppColors.muted),
                filled: true,
                fillColor: AppColors.cream2,
                contentPadding: const EdgeInsets.symmetric(vertical: 10),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          SizedBox(
            height: 44,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 6),
              itemCount: _categories.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, i) {
                final c = _categories[i];
                final selected = c == _category;
                return ChoiceChip(
                  label: Text(c == 'all' ? app.t('all') : app.t(c)),
                  selected: selected,
                  onSelected: (_) {
                    _category = c;
                    _reload();
                  },
                  showCheckmark: false,
                  backgroundColor: Colors.transparent,
                  selectedColor: Theme.of(context).cardColor,
                  side: BorderSide.none,
                  elevation: selected ? 1 : 0,
                  labelStyle: TextStyle(
                    color: selected ? AppColors.maroon : AppColors.muted,
                    fontSize: 12,
                    fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                  ),
                );
              },
            ),
          ),
          Expanded(
            child: AsyncView<List<NewsItem>>(
              key: _listKey,
              loader: () => _api.getNews(category: _category, q: _query),
              isEmpty: (d) => d.isEmpty,
              emptyBuilder: (_) => EmptyState(
                icon: Icons.newspaper_outlined,
                title: app.t('noResults'),
                description: app.t('noResultsDesc'),
              ),
              builder: (context, items) => ListView.builder(
                padding: const EdgeInsets.only(top: 8, bottom: 24),
                itemCount: items.length,
                itemBuilder: (context, i) {
                  final n = items[i];
                  return NewsListTile(
                    item: n,
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => NewsDetailScreen(id: n.id)),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

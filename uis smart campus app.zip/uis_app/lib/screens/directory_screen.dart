import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../core/icon_map.dart';
import '../models/directory_contact_item.dart';
import '../services/api_service.dart';
import '../widgets/async_view.dart';
import '../widgets/empty_state.dart';

class DirectoryScreen extends StatefulWidget {
  const DirectoryScreen({super.key});

  @override
  State<DirectoryScreen> createState() => _DirectoryScreenState();
}

class _DirectoryScreenState extends State<DirectoryScreen> {
  final _api = ApiService();
  String _query = '';
  Key _key = UniqueKey();

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: Text(app.t('directoryTitle')),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(56),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 0, 18, 10),
            child: TextField(
              onSubmitted: (v) => setState(() {
                _query = v;
                _key = UniqueKey();
              }),
              style: const TextStyle(color: AppColors.ink, fontSize: 13),
              decoration: InputDecoration(
                hintText: app.t('searchDirectory'),
                hintStyle: const TextStyle(color: AppColors.muted),
                prefixIcon: const Icon(Icons.search, color: AppColors.muted),
                filled: true,
                fillColor: AppColors.cream2,
                contentPadding: const EdgeInsets.symmetric(vertical: 10),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
        ),
      ),
      body: AsyncView<List<DirectoryContactItem>>(
        key: _key,
        loader: () => _api.getDirectory(q: _query),
        isEmpty: (d) => d.isEmpty,
        emptyBuilder: (_) => EmptyState(
          icon: Icons.contacts_outlined,
          title: app.t('noResults'),
          description: app.t('noResultsDesc'),
        ),
        builder: (context, items) => ListView.separated(
          padding: const EdgeInsets.symmetric(vertical: 6),
          itemCount: items.length,
          separatorBuilder: (_, __) =>
              Divider(height: 1, color: isDark ? AppColors.darkLine : AppColors.line),
          itemBuilder: (context, i) {
            final c = items[i];
            return ListTile(
              onTap: c.phone != null
                  ? () async {
                      final uri = Uri.parse('tel:${c.phone}');
                      if (await canLaunchUrl(uri)) launchUrl(uri);
                    }
                  : null,
              leading: CircleAvatar(
                backgroundColor: AppColors.cream2,
                child: Icon(iconForKey(c.icon), size: 17, color: AppColors.maroon),
              ),
              title: Text(c.name(app.isArabic),
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
              subtitle: c.sub(app.isArabic) != null
                  ? Text(c.sub(app.isArabic)!, style: const TextStyle(fontSize: 11))
                  : null,
              trailing: c.phone != null
                  ? const Icon(Icons.call_outlined, size: 18, color: AppColors.muted)
                  : null,
            );
          },
        ),
      ),
    );
  }
}

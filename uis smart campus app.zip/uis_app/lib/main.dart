import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'package:intl/date_symbol_data_local.dart';

import 'core/app_state.dart';
import 'core/app_colors.dart';
import 'screens/splash_screen.dart';
import 'screens/notifications_screen.dart';
import 'screens/my_requests_screen.dart';
import 'services/notification_service.dart';

final navigatorKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('ar');
  await initializeDateFormatting('en');

  // Push notifications are best-effort: if Firebase isn't configured yet
  // (or the device has no Google Play Services), init() fails quietly and
  // the rest of the app works exactly as before.
  NotificationService.instance.onNotificationTap = _handleNotificationTap;
  unawaited(NotificationService.instance.init());

  runApp(const UisApp());
}

void _handleNotificationTap(Map<String, dynamic> data) {
  final nav = navigatorKey.currentState;
  if (nav == null) return;

  final type = data['type']?.toString();
  switch (type) {
    case 'service_request':
    case 'voice_request':
      nav.push(MaterialPageRoute(builder: (_) => const MyRequestsScreen()));
      break;
    case 'news':
    case 'general':
    default:
      nav.push(MaterialPageRoute(builder: (_) => const NotificationsScreen()));
  }
}

class UisApp extends StatelessWidget {
  const UisApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AppState()..load(),
      child: Consumer<AppState>(
        builder: (context, app, _) {
          return MaterialApp(
            navigatorKey: navigatorKey,
            title: 'UIS Smart Campus',
            debugShowCheckedModeBanner: false,
            theme: buildLightTheme(),
            darkTheme: buildDarkTheme(),
            themeMode: app.themeMode,
            locale: app.locale,
            supportedLocales: const [Locale('ar'), Locale('en')],
            localizationsDelegates: const [
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            builder: (context, child) {
              return Directionality(
                textDirection: app.textDirection,
                child: child ?? const SizedBox.shrink(),
              );
            },
            home: const SplashScreen(),
          );
        },
      ),
    );
  }
}

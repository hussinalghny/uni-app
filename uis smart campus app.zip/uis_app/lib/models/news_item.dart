class NewsItem {
  final int id;
  final String titleAr;
  final String titleEn;
  final String category;
  final String? excerptAr;
  final String? excerptEn;
  final String bodyAr;
  final String bodyEn;
  final String? imageUrl;
  final DateTime? publishedAt;

  NewsItem({
    required this.id,
    required this.titleAr,
    required this.titleEn,
    required this.category,
    this.excerptAr,
    this.excerptEn,
    required this.bodyAr,
    required this.bodyEn,
    this.imageUrl,
    this.publishedAt,
  });

  factory NewsItem.fromJson(Map<String, dynamic> j) => NewsItem(
        id: j['id'],
        titleAr: j['title_ar'] ?? '',
        titleEn: j['title_en'] ?? '',
        category: j['category'] ?? 'news_cat_uni',
        excerptAr: j['excerpt_ar'],
        excerptEn: j['excerpt_en'],
        bodyAr: j['body_ar'] ?? '',
        bodyEn: j['body_en'] ?? '',
        imageUrl: j['image_url'],
        publishedAt:
            j['published_at'] != null ? DateTime.tryParse(j['published_at']) : null,
      );

  String title(bool ar) => ar ? titleAr : titleEn;
  String body(bool ar) => ar ? bodyAr : bodyEn;
  String? excerpt(bool ar) => ar ? excerptAr : excerptEn;
}

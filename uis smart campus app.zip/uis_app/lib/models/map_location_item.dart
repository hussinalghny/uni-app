class MapLocationItem {
  final int id;
  final String icon;
  final String nameAr;
  final String nameEn;
  final String? descriptionAr;
  final String? descriptionEn;
  final double posX;
  final double posY;
  final String colorVariant;

  MapLocationItem({
    required this.id,
    required this.icon,
    required this.nameAr,
    required this.nameEn,
    this.descriptionAr,
    this.descriptionEn,
    required this.posX,
    required this.posY,
    required this.colorVariant,
  });

  factory MapLocationItem.fromJson(Map<String, dynamic> j) => MapLocationItem(
        id: j['id'],
        icon: j['icon'] ?? 'pin',
        nameAr: j['name_ar'] ?? '',
        nameEn: j['name_en'] ?? '',
        descriptionAr: j['description_ar'],
        descriptionEn: j['description_en'],
        posX: double.tryParse(j['pos_x'].toString()) ?? 50,
        posY: double.tryParse(j['pos_y'].toString()) ?? 50,
        colorVariant: j['color_variant'] ?? 'default',
      );

  String name(bool ar) => ar ? nameAr : nameEn;
  String? description(bool ar) => ar ? descriptionAr : descriptionEn;
}

class CampusMapData {
  final String? mapImageUrl;
  final List<MapLocationItem> pins;

  CampusMapData({this.mapImageUrl, this.pins = const []});

  factory CampusMapData.fromJson(Map<String, dynamic> j) => CampusMapData(
        mapImageUrl: j['map_image'],
        pins: (j['pins'] as List<dynamic>? ?? [])
            .map((p) => MapLocationItem.fromJson(p))
            .toList(),
      );
}

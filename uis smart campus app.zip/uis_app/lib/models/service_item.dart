class ServiceItem {
  final int id;
  final String icon;
  final String nameAr;
  final String nameEn;
  final String? descriptionAr;
  final String? descriptionEn;
  final List<String> requirementsAr;
  final List<String> requirementsEn;
  final List<String> stepsAr;
  final List<String> stepsEn;
  final String? durationAr;
  final String? durationEn;

  ServiceItem({
    required this.id,
    required this.icon,
    required this.nameAr,
    required this.nameEn,
    this.descriptionAr,
    this.descriptionEn,
    this.requirementsAr = const [],
    this.requirementsEn = const [],
    this.stepsAr = const [],
    this.stepsEn = const [],
    this.durationAr,
    this.durationEn,
  });

  static List<String> _list(dynamic v) =>
      (v as List<dynamic>? ?? []).map((e) => e.toString()).toList();

  factory ServiceItem.fromJson(Map<String, dynamic> j) => ServiceItem(
        id: j['id'],
        icon: j['icon'] ?? 'form',
        nameAr: j['name_ar'] ?? '',
        nameEn: j['name_en'] ?? '',
        descriptionAr: j['description_ar'],
        descriptionEn: j['description_en'],
        requirementsAr: _list(j['requirements_ar']),
        requirementsEn: _list(j['requirements_en']),
        stepsAr: _list(j['steps_ar']),
        stepsEn: _list(j['steps_en']),
        durationAr: j['duration_ar'],
        durationEn: j['duration_en'],
      );

  String name(bool ar) => ar ? nameAr : nameEn;
  String? description(bool ar) => ar ? descriptionAr : descriptionEn;
  List<String> requirements(bool ar) => ar ? requirementsAr : requirementsEn;
  List<String> steps(bool ar) => ar ? stepsAr : stepsEn;
  String? duration(bool ar) => ar ? durationAr : durationEn;
}

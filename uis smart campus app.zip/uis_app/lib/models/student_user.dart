class StudentUser {
  final int id;
  final String name;
  final String email;
  final String? phone;
  final String? studentNumber;

  StudentUser({
    required this.id,
    required this.name,
    required this.email,
    this.phone,
    this.studentNumber,
  });

  factory StudentUser.fromJson(Map<String, dynamic> j) => StudentUser(
        id: j['id'],
        name: j['name'] ?? '',
        email: j['email'] ?? '',
        phone: j['phone'],
        studentNumber: j['student_number'],
      );
}

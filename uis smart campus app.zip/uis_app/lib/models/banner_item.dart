class BannerItem {
  final int id;
  final String? imageUrl;
  final String? tagAr;
  final String? tagEn;
  final String titleAr;
  final String titleEn;
  final String? subtitleAr;
  final String? subtitleEn;
  final String linkTarget; // news|events|services|colleges|directory|map|media|contact|voice|none

  BannerItem({
    required this.id,
    this.imageUrl,
    this.tagAr,
    this.tagEn,
    required this.titleAr,
    required this.titleEn,
    this.subtitleAr,
    this.subtitleEn,
    required this.linkTarget,
  });

  factory BannerItem.fromJson(Map<String, dynamic> j) => BannerItem(
        id: j['id'],
        imageUrl: j['image_url'],
        tagAr: j['tag_ar'],
        tagEn: j['tag_en'],
        titleAr: j['title_ar'] ?? '',
        titleEn: j['title_en'] ?? '',
        subtitleAr: j['subtitle_ar'],
        subtitleEn: j['subtitle_en'],
        linkTarget: j['link_target'] ?? 'none',
      );

  String title(bool ar) => ar ? titleAr : titleEn;
  String? subtitle(bool ar) => ar ? subtitleAr : subtitleEn;
  String? tag(bool ar) => ar ? tagAr : tagEn;
}

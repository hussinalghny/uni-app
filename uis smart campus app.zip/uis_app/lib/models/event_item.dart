class EventItem {
  final int id;
  final String titleAr;
  final String titleEn;
  final String category;
  final DateTime eventDate;
  final String? timeAr;
  final String? timeEn;
  final String? placeAr;
  final String? placeEn;
  final String? organizerAr;
  final String? organizerEn;
  final String? descriptionAr;
  final String? descriptionEn;
  final String? imageUrl;

  EventItem({
    required this.id,
    required this.titleAr,
    required this.titleEn,
    required this.category,
    required this.eventDate,
    this.timeAr,
    this.timeEn,
    this.placeAr,
    this.placeEn,
    this.organizerAr,
    this.organizerEn,
    this.descriptionAr,
    this.descriptionEn,
    this.imageUrl,
  });

  factory EventItem.fromJson(Map<String, dynamic> j) => EventItem(
        id: j['id'],
        titleAr: j['title_ar'] ?? '',
        titleEn: j['title_en'] ?? '',
        category: j['category'] ?? 'ev_cat_uni',
        eventDate: DateTime.tryParse(j['event_date'] ?? '') ?? DateTime.now(),
        timeAr: j['time_ar'],
        timeEn: j['time_en'],
        placeAr: j['place_ar'],
        placeEn: j['place_en'],
        organizerAr: j['organizer_ar'],
        organizerEn: j['organizer_en'],
        descriptionAr: j['description_ar'],
        descriptionEn: j['description_en'],
        imageUrl: j['image_url'],
      );

  String title(bool ar) => ar ? titleAr : titleEn;
  String? place(bool ar) => ar ? placeAr : placeEn;
  String? time(bool ar) => ar ? timeAr : timeEn;
  String? organizer(bool ar) => ar ? organizerAr : organizerEn;
  String? description(bool ar) => ar ? descriptionAr : descriptionEn;
}

class AppConfigData {
  final String universityNameAr;
  final String universityNameEn;
  final String? logoUrl;
  final String studentsCount;
  final int collegesCount;
  final int departmentsCount;
  final String? registrationUrl;

  AppConfigData({
    required this.universityNameAr,
    required this.universityNameEn,
    this.logoUrl,
    required this.studentsCount,
    required this.collegesCount,
    required this.departmentsCount,
    this.registrationUrl,
  });

  factory AppConfigData.fromJson(Map<String, dynamic> j) => AppConfigData(
        universityNameAr: j['university_name_ar'] ?? 'جامعة العلوم العراقية',
        universityNameEn: j['university_name_en'] ?? 'Al-Iraqia University of Science',
        logoUrl: j['logo_url'],
        studentsCount: j['students_count'] ?? '',
        collegesCount: j['colleges_count'] ?? 0,
        departmentsCount: j['departments_count'] ?? 0,
        registrationUrl: j['registration_url'],
      );

  String name(bool ar) => ar ? universityNameAr : universityNameEn;
}

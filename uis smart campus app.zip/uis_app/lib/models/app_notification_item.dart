class AppNotificationItem {
  final int id;
  final String type; // news | events | services | bell
  final String titleAr;
  final String titleEn;
  final String? descriptionAr;
  final String? descriptionEn;
  final DateTime publishedAt;

  AppNotificationItem({
    required this.id,
    required this.type,
    required this.titleAr,
    required this.titleEn,
    this.descriptionAr,
    this.descriptionEn,
    required this.publishedAt,
  });

  factory AppNotificationItem.fromJson(Map<String, dynamic> j) => AppNotificationItem(
        id: j['id'],
        type: j['type'] ?? 'bell',
        titleAr: j['title_ar'] ?? '',
        titleEn: j['title_en'] ?? '',
        descriptionAr: j['description_ar'],
        descriptionEn: j['description_en'],
        publishedAt: DateTime.tryParse(j['published_at'] ?? '') ?? DateTime.now(),
      );

  String title(bool ar) => ar ? titleAr : titleEn;
  String? description(bool ar) => ar ? descriptionAr : descriptionEn;
}

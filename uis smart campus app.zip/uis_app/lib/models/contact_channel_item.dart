class ContactChannelItem {
  final int id;
  final String type;
  final String icon;
  final String nameAr;
  final String nameEn;
  final String value;
  final bool isSocial;

  ContactChannelItem({
    required this.id,
    required this.type,
    required this.icon,
    required this.nameAr,
    required this.nameEn,
    required this.value,
    required this.isSocial,
  });

  factory ContactChannelItem.fromJson(Map<String, dynamic> j) => ContactChannelItem(
        id: j['id'],
        type: j['type'] ?? '',
        icon: j['icon'] ?? 'website',
        nameAr: j['name_ar'] ?? '',
        nameEn: j['name_en'] ?? '',
        value: j['value'] ?? '',
        isSocial: j['is_social'] == true || j['is_social'] == 1,
      );

  String name(bool ar) => ar ? nameAr : nameEn;
}

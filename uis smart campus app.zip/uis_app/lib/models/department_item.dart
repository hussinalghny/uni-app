class DepartmentItem {
  final int id;
  final String nameAr;
  final String nameEn;

  DepartmentItem({required this.id, required this.nameAr, required this.nameEn});

  factory DepartmentItem.fromJson(Map<String, dynamic> j) => DepartmentItem(
        id: j['id'],
        nameAr: j['name_ar'] ?? '',
        nameEn: j['name_en'] ?? '',
      );

  String name(bool ar) => ar ? nameAr : nameEn;
}

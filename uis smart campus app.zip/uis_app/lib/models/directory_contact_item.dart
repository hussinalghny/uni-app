class DirectoryContactItem {
  final int id;
  final String icon;
  final String nameAr;
  final String nameEn;
  final String? subAr;
  final String? subEn;
  final String? phone;

  DirectoryContactItem({
    required this.id,
    required this.icon,
    required this.nameAr,
    required this.nameEn,
    this.subAr,
    this.subEn,
    this.phone,
  });

  factory DirectoryContactItem.fromJson(Map<String, dynamic> j) => DirectoryContactItem(
        id: j['id'],
        icon: j['icon'] ?? 'directory',
        nameAr: j['name_ar'] ?? '',
        nameEn: j['name_en'] ?? '',
        subAr: j['sub_ar'],
        subEn: j['sub_en'],
        phone: j['phone'],
      );

  String name(bool ar) => ar ? nameAr : nameEn;
  String? sub(bool ar) => ar ? subAr : subEn;
}

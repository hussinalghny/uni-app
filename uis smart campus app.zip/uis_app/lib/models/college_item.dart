import 'department_item.dart';

class CollegeItem {
  final int id;
  final String icon;
  final String nameAr;
  final String nameEn;
  final String? aboutAr;
  final String? aboutEn;
  final String? email;
  final String? phone;
  final String? locationAr;
  final String? locationEn;
  final List<DepartmentItem> departments;

  CollegeItem({
    required this.id,
    required this.icon,
    required this.nameAr,
    required this.nameEn,
    this.aboutAr,
    this.aboutEn,
    this.email,
    this.phone,
    this.locationAr,
    this.locationEn,
    this.departments = const [],
  });

  factory CollegeItem.fromJson(Map<String, dynamic> j) => CollegeItem(
        id: j['id'],
        icon: j['icon'] ?? 'college',
        nameAr: j['name_ar'] ?? '',
        nameEn: j['name_en'] ?? '',
        aboutAr: j['about_ar'],
        aboutEn: j['about_en'],
        email: j['email'],
        phone: j['phone'],
        locationAr: j['location_ar'],
        locationEn: j['location_en'],
        departments: (j['departments'] as List<dynamic>? ?? [])
            .map((d) => DepartmentItem.fromJson(d))
            .toList(),
      );

  String name(bool ar) => ar ? nameAr : nameEn;
  String? about(bool ar) => ar ? aboutAr : aboutEn;
  String? location(bool ar) => ar ? locationAr : locationEn;
}

class MediaItemModel {
  final int id;
  final String type; // photo | video | album
  final String? titleAr;
  final String? titleEn;
  final String? fileUrl;
  final String? videoUrl;
  final String? duration;

  MediaItemModel({
    required this.id,
    required this.type,
    this.titleAr,
    this.titleEn,
    this.fileUrl,
    this.videoUrl,
    this.duration,
  });

  factory MediaItemModel.fromJson(Map<String, dynamic> j) => MediaItemModel(
        id: j['id'],
        type: j['type'] ?? 'photo',
        titleAr: j['title_ar'],
        titleEn: j['title_en'],
        fileUrl: j['file_url'],
        videoUrl: j['video_url'],
        duration: j['duration'],
      );

  String? title(bool ar) => ar ? titleAr : titleEn;
}

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Colors sampled from the official university seal:
/// deep maroon/burgundy + warm cream/gold — kept flat (no gradients),
/// matching the web prototype and admin panel.
class AppColors {
  AppColors._();

  static const Color maroon = Color(0xFF742420);
  static const Color maroonDark = Color(0xFF3D1414);
  static const Color maroonLight = Color(0xFF8A2E29);

  static const Color gold = Color(0xFFAD8036);
  static const Color goldDark = Color(0xFF8E6726);
  static const Color goldBright = Color(0xFFC9A24B);

  static const Color cream = Color(0xFFFBF7EF);
  static const Color cream2 = Color(0xFFF3E9D8);
  static const Color line = Color(0xFFE9DDC4);

  static const Color ink = Color(0xFF2A1E17);
  static const Color ink2 = Color(0xFF5C4A3B);
  static const Color muted = Color(0xFF8C7A67);

  static const Color danger = Color(0xFFB33A34);
  static const Color ok = Color(0xFF6E7C4A);

  // Dark mode
  static const Color darkBg = Color(0xFF120B08);
  static const Color darkSurface = Color(0xFF1D130F);
  static const Color darkLine = Color(0xFF33221A);
  static const Color darkInk = Color(0xFFF3E9DC);
  static const Color darkMuted = Color(0xFF9C8674);
  static const Color darkMaroon = Color(0xFFB0453D);
  static const Color darkGold = Color(0xFFD3A757);
}

/// Full-capsule button shape used everywhere (matches the web's
/// "iOS-style" pill buttons — see index.html's .btn class).
final _capsuleShape = RoundedRectangleBorder(borderRadius: BorderRadius.circular(999));

ThemeData buildLightTheme() {
  final base = ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
  );
  final textTheme = GoogleFonts.cairoTextTheme(base.textTheme);

  return base.copyWith(
    scaffoldBackgroundColor: AppColors.cream,
    textTheme: textTheme.apply(bodyColor: AppColors.ink, displayColor: AppColors.ink),
    colorScheme: ColorScheme.fromSeed(
      seedColor: AppColors.maroon,
      brightness: Brightness.light,
      primary: AppColors.maroon,
      secondary: AppColors.gold,
      surface: Colors.white,
    ),
    // Translucent-light "glass" header — matches the web redesign's
    // blurred nav bar (thin hairline border, dark ink text/icons on a
    // light background, instead of the old solid maroon block).
    appBarTheme: AppBarTheme(
      backgroundColor: AppColors.cream.withOpacity(0.92),
      foregroundColor: AppColors.ink,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleTextStyle: GoogleFonts.cairo(
        color: AppColors.ink, fontSize: 19, fontWeight: FontWeight.w800,
      ),
      iconTheme: const IconThemeData(color: AppColors.maroon),
    ),
    // Light, minimal edge-to-edge tab bar (visually close to the web's
    // blurred floating nav — true backdrop blur isn't worth the added
    // complexity/risk here, but the light translucent look matches).
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Colors.white.withOpacity(0.94),
      surfaceTintColor: Colors.transparent,
      indicatorColor: AppColors.maroon.withOpacity(0.1),
      height: 64,
      labelTextStyle: WidgetStateProperty.resolveWith((states) => GoogleFonts.cairo(
            fontSize: 10,
            fontWeight: states.contains(WidgetState.selected) ? FontWeight.w800 : FontWeight.w600,
            color: states.contains(WidgetState.selected) ? AppColors.maroon : AppColors.muted,
          )),
      iconTheme: WidgetStateProperty.resolveWith((states) => IconThemeData(
            color: states.contains(WidgetState.selected) ? AppColors.maroon : AppColors.muted,
            size: 23,
          )),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(shape: _capsuleShape, padding: const EdgeInsets.symmetric(vertical: 14)),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(shape: _capsuleShape, padding: const EdgeInsets.symmetric(vertical: 14)),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(shape: _capsuleShape, padding: const EdgeInsets.symmetric(vertical: 13)),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(shape: _capsuleShape),
    ),
    chipTheme: base.chipTheme.copyWith(
      shape: _capsuleShape,
      labelStyle: GoogleFonts.cairo(fontSize: 12, fontWeight: FontWeight.w700),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.cream2,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
    ),
    cardColor: Colors.white,
    dividerColor: AppColors.line,
  );
}

ThemeData buildDarkTheme() {
  final base = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
  );
  final textTheme = GoogleFonts.cairoTextTheme(base.textTheme);

  return base.copyWith(
    scaffoldBackgroundColor: AppColors.darkBg,
    textTheme: textTheme.apply(bodyColor: AppColors.darkInk, displayColor: AppColors.darkInk),
    colorScheme: ColorScheme.fromSeed(
      seedColor: AppColors.darkMaroon,
      brightness: Brightness.dark,
      primary: AppColors.darkMaroon,
      secondary: AppColors.darkGold,
      surface: AppColors.darkSurface,
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: AppColors.darkBg.withOpacity(0.92),
      foregroundColor: AppColors.darkInk,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleTextStyle: GoogleFonts.cairo(
        color: AppColors.darkInk, fontSize: 19, fontWeight: FontWeight.w800,
      ),
      iconTheme: const IconThemeData(color: AppColors.darkGold),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: AppColors.darkSurface.withOpacity(0.94),
      surfaceTintColor: Colors.transparent,
      indicatorColor: AppColors.darkGold.withOpacity(0.14),
      height: 64,
      labelTextStyle: WidgetStateProperty.resolveWith((states) => GoogleFonts.cairo(
            fontSize: 10,
            fontWeight: states.contains(WidgetState.selected) ? FontWeight.w800 : FontWeight.w600,
            color: states.contains(WidgetState.selected) ? AppColors.darkGold : AppColors.darkMuted,
          )),
      iconTheme: WidgetStateProperty.resolveWith((states) => IconThemeData(
            color: states.contains(WidgetState.selected) ? AppColors.darkGold : AppColors.darkMuted,
            size: 23,
          )),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(shape: _capsuleShape, padding: const EdgeInsets.symmetric(vertical: 14)),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(shape: _capsuleShape, padding: const EdgeInsets.symmetric(vertical: 14)),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(shape: _capsuleShape, padding: const EdgeInsets.symmetric(vertical: 13)),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(shape: _capsuleShape),
    ),
    chipTheme: base.chipTheme.copyWith(
      shape: _capsuleShape,
      labelStyle: GoogleFonts.cairo(fontSize: 12, fontWeight: FontWeight.w700),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.darkSurface,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
    ),
    cardColor: AppColors.darkSurface,
    dividerColor: AppColors.darkLine,
  );
}

import 'package:flutter/material.dart';

/// The backend stores icons as short string keys (e.g. "college", "build",
/// "voice") so the same key works for both the web prototype's inline SVGs
/// and this app's Material icons. Add new keys here as new content types
/// are introduced from the admin panel.
IconData iconForKey(String? key) {
  switch (key) {
    case 'college':
      return Icons.school_outlined;
    case 'build':
      return Icons.memory_outlined;
    case 'econ':
      return Icons.bar_chart_outlined;
    case 'law':
      return Icons.gavel_outlined;
    case 'arts':
      return Icons.palette_outlined;
    case 'help':
      return Icons.help_outline;
    case 'form':
      return Icons.description_outlined;
    case 'doc':
      return Icons.article_outlined;
    case 'cert':
      return Icons.workspace_premium_outlined;
    case 'voice':
      return Icons.record_voice_over_outlined;
    case 'chat':
      return Icons.chat_bubble_outline;
    case 'guide':
      return Icons.menu_book_outlined;
    case 'approve':
      return Icons.task_alt_outlined;
    case 'directory':
      return Icons.contacts_outlined;
    case 'admin_link':
      return Icons.account_balance_outlined;
    case 'shield':
      return Icons.shield_outlined;
    case 'events':
      return Icons.event_outlined;
    case 'book':
      return Icons.menu_book_outlined;
    case 'bell':
      return Icons.notifications_none_outlined;
    case 'news':
      return Icons.newspaper_outlined;
    case 'services':
      return Icons.stars_outlined;
    case 'map':
      return Icons.map_outlined;
    case 'media':
      return Icons.perm_media_outlined;
    case 'contact':
      return Icons.mail_outline;
    case 'pin':
      return Icons.location_on_outlined;
    case 'location':
      return Icons.place_outlined;
    case 'website':
      return Icons.language_outlined;
    case 'fb':
      return Icons.facebook_outlined;
    case 'ig':
      return Icons.camera_alt_outlined;
    case 'yt':
      return Icons.play_circle_outline;
    case 'li':
      return Icons.business_center_outlined;
    case 'play':
      return Icons.play_circle_outline;
    case 'check':
      return Icons.check_circle_outline;
    case 'share':
      return Icons.share_outlined;
    case 'search':
      return Icons.search;
    case 'clock':
      return Icons.access_time;
    case 'calendar':
      return Icons.calendar_today_outlined;
    case 'tag':
      return Icons.label_outline;
    case 'globe':
      return Icons.public;
    case 'moon':
      return Icons.dark_mode_outlined;
    default:
      return Icons.circle_outlined;
  }
}

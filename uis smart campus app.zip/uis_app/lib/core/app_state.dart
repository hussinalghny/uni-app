import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'strings.dart';
import 'auth_token_store.dart';
import '../models/student_user.dart';
import '../services/api_service.dart';

class AppState extends ChangeNotifier {
  String _lang = 'ar';
  ThemeMode _themeMode = ThemeMode.light;
  bool _loaded = false;
  StudentUser? _student;

  String get lang => _lang;
  bool get isArabic => _lang == 'ar';
  ThemeMode get themeMode => _themeMode;
  bool get isDark => _themeMode == ThemeMode.dark;
  bool get loaded => _loaded;

  StudentUser? get student => _student;
  bool get isLoggedIn => _student != null;

  TextDirection get textDirection =>
      isArabic ? TextDirection.rtl : TextDirection.ltr;

  Locale get locale => Locale(_lang);

  String t(String key) => AppStrings.t(key, _lang);

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    _lang = prefs.getString('uis_lang') ?? 'ar';
    final dark = prefs.getBool('uis_dark') ?? false;
    _themeMode = dark ? ThemeMode.dark : ThemeMode.light;

    final token = prefs.getString('uis_auth_token');
    if (token != null && token.isNotEmpty) {
      AuthTokenStore.token = token;
      // Verify the token is still valid and fetch the current profile;
      // if it's expired/invalid, silently fall back to logged-out state.
      try {
        _student = await ApiService().me();
      } catch (_) {
        AuthTokenStore.token = null;
        await prefs.remove('uis_auth_token');
      }
    }

    _loaded = true;
    notifyListeners();
  }

  Future<void> setLang(String lang) async {
    _lang = lang;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('uis_lang', lang);
  }

  Future<void> toggleDark() async {
    _themeMode = isDark ? ThemeMode.light : ThemeMode.dark;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('uis_dark', isDark);
  }

  Future<void> setSession(String token, StudentUser student) async {
    AuthTokenStore.token = token;
    _student = student;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('uis_auth_token', token);
  }

  Future<void> logout() async {
    try {
      await ApiService().logout();
    } catch (_) {
      // Local logout still proceeds even if the network call fails.
    }
    AuthTokenStore.token = null;
    _student = null;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('uis_auth_token');
  }
}

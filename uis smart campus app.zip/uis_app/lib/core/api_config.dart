/// Central place to configure the backend base URL.
///
/// Change [apiBaseUrl] if you move the backend to a different domain.
/// If you set an API key in the control panel (Settings > حماية الـ API),
/// put the same value in [apiKey] below so write requests aren't rejected.
class ApiConfig {
  ApiConfig._();

  static const String baseUrl = 'https://app.aisu.edu.iq';
  static const String apiBaseUrl = '$baseUrl/api/v1';

  /// Leave empty if you haven't set an API key in the control panel.
  static const String apiKey = '';
}

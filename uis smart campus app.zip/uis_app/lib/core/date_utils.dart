import 'package:intl/intl.dart';

String formatDate(DateTime date, bool ar) {
  final formatter = DateFormat.yMMMd(ar ? 'ar' : 'en');
  try {
    return formatter.format(date);
  } catch (_) {
    // Fallback if the 'ar' intl locale data isn't initialized.
    return DateFormat('d MMM y').format(date);
  }
}

/// Holds the current student's auth token in memory so [ApiService] (which
/// is instantiated fresh in many screens) can attach it to requests without
/// needing full dependency injection plumbing. The source of truth for
/// persistence is [AppState], which loads/saves this via SharedPreferences.
class AuthTokenStore {
  AuthTokenStore._();
  static String? token;
}

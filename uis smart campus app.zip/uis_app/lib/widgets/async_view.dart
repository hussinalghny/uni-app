import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_state.dart';
import '../core/app_colors.dart';
import '../services/api_service.dart';

/// Wraps a Future<T> with consistent loading / error+retry / data states,
/// used by every list/detail screen instead of repeating FutureBuilder
/// boilerplate.
class AsyncView<T> extends StatefulWidget {
  final Future<T> Function() loader;
  final Widget Function(BuildContext context, T data) builder;
  final Widget Function(BuildContext context)? emptyBuilder;
  final bool Function(T data)? isEmpty;

  const AsyncView({
    super.key,
    required this.loader,
    required this.builder,
    this.emptyBuilder,
    this.isEmpty,
  });

  @override
  State<AsyncView<T>> createState() => _AsyncViewState<T>();
}

class _AsyncViewState<T> extends State<AsyncView<T>> {
  late Future<T> _future;

  @override
  void initState() {
    super.initState();
    _future = widget.loader();
  }

  void _retry() {
    setState(() {
      _future = widget.loader();
    });
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return FutureBuilder<T>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(
            child: Padding(
              padding: EdgeInsets.all(40),
              child: CircularProgressIndicator(color: AppColors.maroon),
            ),
          );
        }
        if (snap.hasError) {
          final isNetwork = snap.error is ApiException &&
              (snap.error as ApiException).message == 'network';
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.wifi_off_rounded, size: 44, color: AppColors.muted),
                  const SizedBox(height: 12),
                  Text(
                    isNetwork ? app.t('networkError') : app.t('noResults'),
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: AppColors.muted, fontSize: 13),
                  ),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: _retry,
                    style: FilledButton.styleFrom(backgroundColor: AppColors.maroon),
                    child: Text(app.t('retry')),
                  ),
                ],
              ),
            ),
          );
        }
        final data = snap.data as T;
        if (widget.isEmpty != null && widget.isEmpty!(data) && widget.emptyBuilder != null) {
          return widget.emptyBuilder!(context);
        }
        return widget.builder(context, data);
      },
    );
  }
}

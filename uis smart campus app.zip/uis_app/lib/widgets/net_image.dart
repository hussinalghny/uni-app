import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../core/app_colors.dart';
import '../core/icon_map.dart';

class NetImage extends StatelessWidget {
  final String? url;
  final double? width;
  final double? height;
  final BorderRadius? radius;
  final String fallbackIcon;

  const NetImage({
    super.key,
    required this.url,
    this.width,
    this.height,
    this.radius,
    this.fallbackIcon = 'media',
  });

  @override
  Widget build(BuildContext context) {
    final placeholder = Container(
      width: width,
      height: height,
      color: AppColors.cream2,
      alignment: Alignment.center,
      child: Icon(iconForKey(fallbackIcon), color: AppColors.muted, size: 26),
    );

    Widget child;
    if (url == null || url!.isEmpty) {
      child = placeholder;
    } else {
      child = CachedNetworkImage(
        imageUrl: url!,
        width: width,
        height: height,
        fit: BoxFit.cover,
        placeholder: (_, __) => placeholder,
        errorWidget: (_, __, ___) => placeholder,
      );
    }

    if (radius != null) {
      return ClipRRect(borderRadius: radius!, child: child);
    }
    return child;
  }
}

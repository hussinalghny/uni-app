import 'package:flutter/material.dart';
import '../core/app_colors.dart';

class SectionHeader extends StatelessWidget {
  final String title;
  final String? eyebrow;
  final VoidCallback? onViewAll;
  final String? viewAllLabel;

  const SectionHeader({
    super.key,
    required this.title,
    this.eyebrow,
    this.onViewAll,
    this.viewAllLabel,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (eyebrow != null)
                Text(
                  eyebrow!.toUpperCase(),
                  style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.2,
                    color: isDark ? AppColors.darkGold : AppColors.goldDark,
                  ),
                ),
              const SizedBox(height: 2),
              Text(title,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
            ],
          ),
          if (onViewAll != null)
            InkWell(
              onTap: onViewAll,
              child: Row(
                children: [
                  Text(viewAllLabel ?? '',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: isDark ? AppColors.darkGold : AppColors.maroon,
                      )),
                  Icon(Icons.chevron_left,
                      size: 16, color: isDark ? AppColors.darkGold : AppColors.maroon),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

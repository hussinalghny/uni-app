import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_colors.dart';
import '../core/app_state.dart';
import '../core/date_utils.dart';
import '../models/news_item.dart';
import 'net_image.dart';

class NewsCard extends StatelessWidget {
  final NewsItem item;
  final VoidCallback onTap;
  final double width;

  const NewsCard({super.key, required this.item, required this.onTap, this.width = 240});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: width,
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: isDark ? AppColors.darkLine : AppColors.line),
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            NetImage(url: item.imageUrl, height: 110, fallbackIcon: 'news'),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _CategoryChip(label: app.t(item.category)),
                  const SizedBox(height: 8),
                  Text(
                    item.title(app.isArabic),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13),
                  ),
                  const SizedBox(height: 8),
                  if (item.publishedAt != null)
                    Row(
                      children: [
                        const Icon(Icons.access_time, size: 12, color: AppColors.muted),
                        const SizedBox(width: 4),
                        Text(formatDate(item.publishedAt!, app.isArabic),
                            style: const TextStyle(fontSize: 10.5, color: AppColors.muted)),
                      ],
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class NewsListTile extends StatelessWidget {
  final NewsItem item;
  final VoidCallback onTap;

  const NewsListTile({super.key, required this.item, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        margin: const EdgeInsets.fromLTRB(18, 0, 18, 10),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: isDark ? AppColors.darkLine : AppColors.line),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            NetImage(
              url: item.imageUrl,
              width: 74,
              height: 74,
              radius: BorderRadius.circular(10),
              fallbackIcon: 'news',
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _CategoryChip(label: app.t(item.category)),
                  const SizedBox(height: 6),
                  Text(
                    item.title(app.isArabic),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13),
                  ),
                  if (item.publishedAt != null) ...[
                    const SizedBox(height: 6),
                    Text(formatDate(item.publishedAt!, app.isArabic),
                        style: const TextStyle(fontSize: 10.5, color: AppColors.muted)),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CategoryChip extends StatelessWidget {
  final String label;
  const _CategoryChip({required this.label});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF2E1815) : const Color(0xFFF1E1DE),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w800,
          color: isDark ? AppColors.darkGold : AppColors.maroon,
        ),
      ),
    );
  }
}
